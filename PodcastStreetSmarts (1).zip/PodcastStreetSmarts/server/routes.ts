import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertVideoSchema, insertPhotoSchema, insertForumPostSchema, insertSiteSettingsSchema } from "@shared/schema";
import { setupAuth, isAuthenticated, isAdmin } from "./replitAuth";
import bcrypt from "bcrypt";
import paypal from "paypal-rest-sdk";

export async function registerRoutes(app: Express): Promise<Server> {
  // Configure PayPal
  paypal.configure({
    mode: 'sandbox', // Change to 'live' for production
    client_id: process.env.PAYPAL_CLIENT_ID!,
    client_secret: process.env.PAYPAL_CLIENT_SECRET!
  });

  // Initialize admin credentials if they don't exist
  await initializeAdminCredentials();

  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });
  // Videos API
  app.get("/api/videos", async (req, res) => {
    try {
      const category = req.query.category as string;
      const videos = category 
        ? await storage.getVideosByCategory(category)
        : await storage.getAllVideos();
      res.json(videos);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch videos" });
    }
  });

  app.post("/api/videos", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const validatedData = insertVideoSchema.parse(req.body);
      const video = await storage.createVideo(validatedData);
      res.status(201).json(video);
    } catch (error) {
      res.status(400).json({ message: "Invalid video data" });
    }
  });

  app.put("/api/videos/:id", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertVideoSchema.parse(req.body);
      const video = await storage.updateVideo(id, validatedData);
      if (!video) {
        return res.status(404).json({ message: "Video not found" });
      }
      res.json(video);
    } catch (error) {
      res.status(400).json({ message: "Invalid video data" });
    }
  });

  app.delete("/api/videos/:id", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteVideo(id);
      if (!success) {
        return res.status(404).json({ message: "Video not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete video" });
    }
  });

  // Photos API
  app.get("/api/photos", async (req, res) => {
    try {
      const category = req.query.category as string;
      const photos = category 
        ? await storage.getPhotosByCategory(category)
        : await storage.getAllPhotos();
      res.json(photos);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch photos" });
    }
  });

  app.post("/api/photos", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const validatedData = insertPhotoSchema.parse(req.body);
      const photo = await storage.createPhoto(validatedData);
      res.status(201).json(photo);
    } catch (error) {
      res.status(400).json({ message: "Invalid photo data" });
    }
  });

  app.put("/api/photos/:id", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertPhotoSchema.parse(req.body);
      const photo = await storage.updatePhoto(id, validatedData);
      if (!photo) {
        return res.status(404).json({ message: "Photo not found" });
      }
      res.json(photo);
    } catch (error) {
      res.status(400).json({ message: "Invalid photo data" });
    }
  });

  app.delete("/api/photos/:id", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deletePhoto(id);
      if (!success) {
        return res.status(404).json({ message: "Photo not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete photo" });
    }
  });

  // Forum API
  app.get("/api/forum", async (req, res) => {
    try {
      const category = req.query.category as string;
      const posts = category 
        ? await storage.getForumPostsByCategory(category)
        : await storage.getAllForumPosts();
      res.json(posts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch forum posts" });
    }
  });

  app.post("/api/forum", async (req, res) => {
    try {
      const validatedData = insertForumPostSchema.parse(req.body);
      const post = await storage.createForumPost(validatedData);
      res.status(201).json(post);
    } catch (error) {
      res.status(400).json({ message: "Invalid forum post data" });
    }
  });

  app.delete("/api/forum/:id", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteForumPost(id);
      if (!success) {
        return res.status(404).json({ message: "Forum post not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete forum post" });
    }
  });

  // Site Settings API
  app.get("/api/settings", async (req, res) => {
    try {
      const settings = await storage.getSiteSettings();
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch site settings" });
    }
  });

  app.put("/api/settings", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const validatedData = insertSiteSettingsSchema.parse(req.body);
      const settings = await storage.updateSiteSettings(validatedData);
      res.json(settings);
    } catch (error) {
      res.status(400).json({ message: "Invalid settings data" });
    }
  });

  // Admin login route
  app.post('/api/admin/login', async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: 'Username and password required' });
      }
      
      const admin = await storage.getAdminByUsername(username);
      if (!admin || !admin.isActive) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }
      
      const isValid = await bcrypt.compare(password, admin.passwordHash);
      if (!isValid) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }
      
      // Set session or token here
      (req.session as any).adminId = admin.id;
      (req.session as any).isAdmin = true;
      
      res.json({ message: 'Login successful', admin: { id: admin.id, username: admin.username } });
    } catch (error) {
      console.error('Admin login error:', error);
      res.status(500).json({ message: 'Login failed' });
    }
  });

  // Admin logout route
  app.post('/api/admin/logout', (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: 'Logout failed' });
      }
      res.json({ message: 'Logout successful' });
    });
  });

  // Admin authentication check route
  app.get('/api/admin/check', (req, res) => {
    const session = req.session as any;
    if (session.adminId && session.isAdmin) {
      res.json({ authenticated: true, adminId: session.adminId });
    } else {
      res.status(401).json({ authenticated: false });
    }
  });

  // PayPal donation route
  app.post('/api/donate', async (req, res) => {
    try {
      const { amount, currency = 'USD' } = req.body;
      
      if (!amount || amount <= 0) {
        return res.status(400).json({ message: 'Valid amount required' });
      }

      const paymentData = {
        intent: 'sale',
        payer: {
          payment_method: 'paypal'
        },
        redirect_urls: {
          return_url: `${req.protocol}://${req.get('host')}/donate/success`,
          cancel_url: `${req.protocol}://${req.get('host')}/donate/cancel`
        },
        transactions: [{
          item_list: {
            items: [{
              name: 'Donation to Street Smarts & Bad Decisions',
              sku: 'donation',
              price: amount.toString(),
              currency: currency,
              quantity: 1
            }]
          },
          amount: {
            currency: currency,
            total: amount.toString()
          },
          description: 'Support the Street Smarts & Bad Decisions podcast'
        }]
      };

      paypal.payment.create(paymentData, (error, payment) => {
        if (error) {
          console.error('PayPal payment error:', error);
          return res.status(500).json({ message: 'Payment creation failed' });
        }
        
        const approvalUrl = payment.links?.find(link => link.rel === 'approval_url')?.href;
        if (!approvalUrl) {
          return res.status(500).json({ message: 'Payment approval URL not found' });
        }
        
        res.json({ approvalUrl, paymentId: payment.id });
      });
    } catch (error) {
      console.error('Donation error:', error);
      res.status(500).json({ message: 'Donation failed' });
    }
  });

  // PayPal payment execution route
  app.post('/api/donate/execute', async (req, res) => {
    try {
      const { paymentId, payerId } = req.body;
      
      if (!paymentId || !payerId) {
        return res.status(400).json({ message: 'Payment ID and Payer ID required' });
      }

      const executeData = {
        payer_id: payerId
      };

      paypal.payment.execute(paymentId, executeData, (error, payment) => {
        if (error) {
          console.error('PayPal execution error:', error);
          return res.status(500).json({ message: 'Payment execution failed' });
        }
        
        res.json({ message: 'Payment successful', payment });
      });
    } catch (error) {
      console.error('Payment execution error:', error);
      res.status(500).json({ message: 'Payment execution failed' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Initialize admin credentials
async function initializeAdminCredentials() {
  try {
    const existingAdmin = await storage.getAdminByUsername('ssbd');
    if (!existingAdmin) {
      const hashedPassword = await bcrypt.hash('4200', 10);
      await storage.createAdminCredentials({
        username: 'ssbd',
        passwordHash: hashedPassword,
        isActive: true
      });
      console.log('Admin credentials initialized successfully');
    }
  } catch (error) {
    console.error('Error initializing admin credentials:', error);
  }
}
