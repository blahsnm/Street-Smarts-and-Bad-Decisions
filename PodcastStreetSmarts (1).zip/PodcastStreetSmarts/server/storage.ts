import {
  users,
  videos,
  photos,
  forumPosts,
  siteSettings,
  adminCredentials,
  type User,
  type UpsertUser,
  type Video,
  type InsertVideo,
  type Photo,
  type InsertPhoto,
  type ForumPost,
  type InsertForumPost,
  type SiteSettings,
  type InsertSiteSettings,
  type AdminCredentials,
  type InsertAdminCredentials,
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Video operations
  getAllVideos(): Promise<Video[]>;
  getVideosByCategory(category: string): Promise<Video[]>;
  createVideo(video: InsertVideo): Promise<Video>;
  updateVideo(id: number, video: Partial<InsertVideo>): Promise<Video | undefined>;
  deleteVideo(id: number): Promise<boolean>;
  
  // Photo operations
  getAllPhotos(): Promise<Photo[]>;
  getPhotosByCategory(category: string): Promise<Photo[]>;
  createPhoto(photo: InsertPhoto): Promise<Photo>;
  updatePhoto(id: number, photo: Partial<InsertPhoto>): Promise<Photo | undefined>;
  deletePhoto(id: number): Promise<boolean>;
  
  // Forum operations
  getAllForumPosts(): Promise<ForumPost[]>;
  getForumPostsByCategory(category: string): Promise<ForumPost[]>;
  createForumPost(post: InsertForumPost): Promise<ForumPost>;
  deleteForumPost(id: number): Promise<boolean>;
  
  // Site settings operations
  getSiteSettings(): Promise<SiteSettings | undefined>;
  updateSiteSettings(settings: InsertSiteSettings): Promise<SiteSettings>;
  
  // Admin credentials operations
  getAdminByUsername(username: string): Promise<AdminCredentials | undefined>;
  createAdminCredentials(credentials: InsertAdminCredentials): Promise<AdminCredentials>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Video operations
  async getAllVideos(): Promise<Video[]> {
    return await db.select().from(videos).orderBy(videos.createdAt);
  }

  async getVideosByCategory(category: string): Promise<Video[]> {
    return await db.select().from(videos).where(eq(videos.category, category)).orderBy(videos.createdAt);
  }

  async createVideo(insertVideo: InsertVideo): Promise<Video> {
    const [video] = await db.insert(videos).values({
      ...insertVideo,
      description: insertVideo.description || null,
      thumbnail: insertVideo.thumbnail || null,
      videoUrl: insertVideo.videoUrl || null,
      duration: insertVideo.duration || null,
      category: insertVideo.category || null,
    }).returning();
    return video;
  }

  async updateVideo(id: number, videoData: Partial<InsertVideo>): Promise<Video | undefined> {
    const [video] = await db.update(videos).set(videoData).where(eq(videos.id, id)).returning();
    return video || undefined;
  }

  async deleteVideo(id: number): Promise<boolean> {
    const result = await db.delete(videos).where(eq(videos.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Photo operations
  async getAllPhotos(): Promise<Photo[]> {
    return await db.select().from(photos).orderBy(photos.createdAt);
  }

  async getPhotosByCategory(category: string): Promise<Photo[]> {
    return await db.select().from(photos).where(eq(photos.category, category)).orderBy(photos.createdAt);
  }

  async createPhoto(insertPhoto: InsertPhoto): Promise<Photo> {
    const [photo] = await db.insert(photos).values({
      ...insertPhoto,
      description: insertPhoto.description || null,
      category: insertPhoto.category || null,
    }).returning();
    return photo;
  }

  async updatePhoto(id: number, photoData: Partial<InsertPhoto>): Promise<Photo | undefined> {
    const [photo] = await db.update(photos).set(photoData).where(eq(photos.id, id)).returning();
    return photo || undefined;
  }

  async deletePhoto(id: number): Promise<boolean> {
    const result = await db.delete(photos).where(eq(photos.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Forum operations
  async getAllForumPosts(): Promise<ForumPost[]> {
    return await db.select().from(forumPosts).orderBy(forumPosts.createdAt);
  }

  async getForumPostsByCategory(category: string): Promise<ForumPost[]> {
    return await db.select().from(forumPosts).where(eq(forumPosts.category, category)).orderBy(forumPosts.createdAt);
  }

  async createForumPost(insertPost: InsertForumPost): Promise<ForumPost> {
    const [post] = await db.insert(forumPosts).values({
      ...insertPost,
      category: insertPost.category || null,
      replies: 0,
    }).returning();
    return post;
  }

  async deleteForumPost(id: number): Promise<boolean> {
    const result = await db.delete(forumPosts).where(eq(forumPosts.id, id));
    return (result.rowCount || 0) > 0;
  }

  // Site settings operations
  async getSiteSettings(): Promise<SiteSettings | undefined> {
    const [settings] = await db.select().from(siteSettings).limit(1);
    return settings || undefined;
  }

  async updateSiteSettings(settingsData: InsertSiteSettings): Promise<SiteSettings> {
    const existingSettings = await this.getSiteSettings();
    
    if (existingSettings) {
      const [settings] = await db
        .update(siteSettings)
        .set({ 
          logoUrl: settingsData.logoUrl || null,
          siteName: settingsData.siteName || null,
          siteDescription: settingsData.siteDescription || null,
          primaryColor: settingsData.primaryColor || null,
          secondaryColor: settingsData.secondaryColor || null,
          socialLinks: settingsData.socialLinks as any || null,
          stripePublicKey: settingsData.stripePublicKey || null,
          donationGoal: settingsData.donationGoal || null,
          updatedAt: new Date() 
        })
        .where(eq(siteSettings.id, existingSettings.id))
        .returning();
      return settings;
    } else {
      const [settings] = await db.insert(siteSettings).values({
        logoUrl: settingsData.logoUrl || null,
        siteName: settingsData.siteName || null,
        siteDescription: settingsData.siteDescription || null,
        primaryColor: settingsData.primaryColor || null,
        secondaryColor: settingsData.secondaryColor || null,
        socialLinks: settingsData.socialLinks as any || null,
        stripePublicKey: settingsData.stripePublicKey || null,
        donationGoal: settingsData.donationGoal || null,
      }).returning();
      return settings;
    }
  }

  async getAdminByUsername(username: string): Promise<AdminCredentials | undefined> {
    const [admin] = await db
      .select()
      .from(adminCredentials)
      .where(eq(adminCredentials.username, username));
    return admin;
  }

  async createAdminCredentials(credentials: InsertAdminCredentials): Promise<AdminCredentials> {
    const [admin] = await db
      .insert(adminCredentials)
      .values(credentials)
      .returning();
    return admin;
  }
}

export const storage = new DatabaseStorage();
