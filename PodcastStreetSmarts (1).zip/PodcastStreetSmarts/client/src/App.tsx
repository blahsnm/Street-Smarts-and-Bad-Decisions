import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Layout from "@/components/Layout";
import Home from "@/pages/Home";
import Videos from "@/pages/Videos";
import Photography from "@/pages/Photography";
import StreetSmarts from "@/pages/StreetSmarts";
import BadDecisions from "@/pages/BadDecisions";
import Forum from "@/pages/Forum";
import About from "@/pages/About";
import Donate from "@/pages/Donate";
import Admin from "@/pages/Admin";
import AdminLogin from "@/pages/AdminLogin";
import DonateSuccess from "@/pages/DonateSuccess";
import DonateCancel from "@/pages/DonateCancel";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/videos" component={Videos} />
        <Route path="/photography" component={Photography} />
        <Route path="/street-smarts" component={StreetSmarts} />
        <Route path="/bad-decisions" component={BadDecisions} />
        <Route path="/forum" component={Forum} />
        <Route path="/about" component={About} />
        <Route path="/donate" component={Donate} />
        <Route path="/admin" component={Admin} />
        <Route path="/admin/login" component={AdminLogin} />
        <Route path="/donate/success" component={DonateSuccess} />
        <Route path="/donate/cancel" component={DonateCancel} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
