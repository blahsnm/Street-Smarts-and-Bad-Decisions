import { Link } from "wouter";
import { Mic } from "lucide-react";
import { FaSpotify, FaYoutube, FaInstagram, FaTwitter } from "react-icons/fa";

export default function Footer() {
  return (
    <footer className="bg-dark-surface border-t border-gray-800 py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-gradient-to-r from-light-blue to-accent-blue rounded-lg flex items-center justify-center">
                <Mic className="text-white" size={20} />
              </div>
              <div>
                <h3 className="text-lg font-bold text-text-light">Street Smarts & Bad Decisions</h3>
              </div>
            </div>
            <p className="text-gray-400 mb-6 max-w-md">
              Where wisdom meets chaos in the digital age. Join our community of urban navigators sharing stories that matter.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-accent-blue transition-colors duration-300">
                <FaSpotify size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-accent-blue transition-colors duration-300">
                <FaYoutube size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-accent-blue transition-colors duration-300">
                <FaInstagram size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-accent-blue transition-colors duration-300">
                <FaTwitter size={20} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-text-light mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><Link href="/videos" className="text-gray-400 hover:text-accent-blue transition-colors duration-300">Latest Episodes</Link></li>
              <li><Link href="/photography" className="text-gray-400 hover:text-accent-blue transition-colors duration-300">Photography</Link></li>
              <li><Link href="/forum" className="text-gray-400 hover:text-accent-blue transition-colors duration-300">Community Forum</Link></li>
              <li><Link href="/about" className="text-gray-400 hover:text-accent-blue transition-colors duration-300">About Us</Link></li>
            </ul>
          </div>

          {/* Content */}
          <div>
            <h4 className="font-semibold text-text-light mb-4">Content</h4>
            <ul className="space-y-2">
              <li><Link href="/street-smarts" className="text-gray-400 hover:text-accent-blue transition-colors duration-300">Street Smarts</Link></li>
              <li><Link href="/bad-decisions" className="text-gray-400 hover:text-accent-blue transition-colors duration-300">Bad Decisions</Link></li>
              <li><a href="#" className="text-gray-400 hover:text-accent-blue transition-colors duration-300">Newsletter</a></li>
              <li><Link href="/donate" className="text-gray-400 hover:text-accent-blue transition-colors duration-300">Support Us</Link></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center">
          <p className="text-gray-500 text-sm">
            © 2024 Street Smarts & Bad Decisions. All rights reserved. | 
            <a href="#" className="hover:text-accent-blue transition-colors duration-300 ml-1">Privacy Policy</a> | 
            <a href="#" className="hover:text-accent-blue transition-colors duration-300 ml-1">Terms of Service</a>
          </p>
        </div>
      </div>
    </footer>
  );
}
