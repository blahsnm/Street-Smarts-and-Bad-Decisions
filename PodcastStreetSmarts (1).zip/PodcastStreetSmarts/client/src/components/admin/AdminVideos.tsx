import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Video, 
  Plus, 
  Edit, 
  Trash2, 
  Calendar,
  Eye,
  Clock,
  Upload,
  FileVideo,
  Download,
  Copy,
  Filter,
  Search
} from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import FileUpload from "@/components/admin/FileUpload";
import type { Video as VideoType, InsertVideo } from "@shared/schema";

export default function AdminVideos() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingVideo, setEditingVideo] = useState<VideoType | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategory, setFilterCategory] = useState("all");
  const { toast } = useToast();

  const { data: videos, isLoading } = useQuery<VideoType[]>({
    queryKey: ["/api/videos"],
  });

  const createMutation = useMutation({
    mutationFn: async (videoData: InsertVideo) => {
      return await apiRequest("POST", "/api/videos", videoData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      setIsDialogOpen(false);
      setEditingVideo(null);
      toast({
        title: "Success",
        description: "Video added successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add video. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: InsertVideo }) => {
      return await apiRequest("PUT", `/api/videos/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      setIsDialogOpen(false);
      setEditingVideo(null);
      toast({
        title: "Success",
        description: "Video updated successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update video. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("DELETE", `/api/videos/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      toast({
        title: "Success",
        description: "Video deleted successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete video. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const videoData: InsertVideo = {
      title: formData.get("title") as string,
      description: formData.get("description") as string || null,
      thumbnail: formData.get("thumbnail") as string || null,
      videoUrl: formData.get("videoUrl") as string || null,
      duration: formData.get("duration") as string || null,
      category: formData.get("category") as string || null,
    };

    if (editingVideo) {
      updateMutation.mutate({ id: editingVideo.id, data: videoData });
    } else {
      createMutation.mutate(videoData);
    }
  };

  const handleEdit = (video: VideoType) => {
    setEditingVideo(video);
    setIsDialogOpen(true);
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this video?")) {
      deleteMutation.mutate(id);
    }
  };

  const openNewVideoDialog = () => {
    setEditingVideo(null);
    setSelectedFile(null);
    setIsDialogOpen(true);
  };

  const handleFileSelect = (file: File) => {
    setSelectedFile(file);
    toast({
      title: "File selected",
      description: `${file.name} ready for upload`,
    });
  };

  const handleBulkDelete = (videoIds: number[]) => {
    if (confirm(`Are you sure you want to delete ${videoIds.length} videos?`)) {
      videoIds.forEach(id => deleteMutation.mutate(id));
    }
  };

  const handleDuplicate = (video: VideoType) => {
    const duplicatedVideo: InsertVideo = {
      title: `${video.title} (Copy)`,
      description: video.description,
      thumbnail: video.thumbnail,
      videoUrl: video.videoUrl,
      duration: video.duration,
      category: video.category,
    };
    createMutation.mutate(duplicatedVideo);
  };

  const filteredVideos = videos?.filter(video => {
    const matchesSearch = searchTerm === "" || 
      video.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (video.description && video.description.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = filterCategory === "all" || video.category === filterCategory;
    return matchesSearch && matchesCategory;
  }) || [];

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-10 w-32" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="bg-dark-surface">
              <Skeleton className="aspect-video w-full" />
              <CardContent className="p-4">
                <Skeleton className="h-6 w-full mb-2" />
                <Skeleton className="h-4 w-3/4 mb-2" />
                <Skeleton className="h-4 w-1/2" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-text-light">Videos Management</h2>
          <p className="text-gray-400">Manage your podcast episodes and video content, Malissa</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button 
            onClick={openNewVideoDialog} 
            className="bg-light-blue hover:bg-accent-blue"
          >
            <Plus className="mr-2" size={16} />
            Create New Video
          </Button>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button 
                onClick={openNewVideoDialog} 
                className="bg-light-blue hover:bg-accent-blue"
              >
                <Upload className="mr-2" size={16} />
                Upload Video
              </Button>
            </DialogTrigger>
          <DialogContent className="bg-dark-surface text-text-light max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-xl">
                {editingVideo ? "Edit Video" : "Create New Video"}
              </DialogTitle>
              <p className="text-sm text-gray-400">
                {editingVideo ? "Update your video details" : "Add a new episode or video to your collection"}
              </p>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-6">
              
              {/* File Upload Section */}
              {!editingVideo && (
                <div className="space-y-4">
                  <div>
                    <Label className="text-base font-medium">Upload Video File *</Label>
                    <p className="text-xs text-gray-500 mb-3">
                      Upload your podcast episode or video content (Max 500MB)
                    </p>
                    <FileUpload 
                      onFileSelect={handleFileSelect}
                      acceptedTypes="video/*,.mp4,.mov,.avi,.mkv,.webm"
                      maxSize={500}
                      preview={false}
                    />
                    {selectedFile && (
                      <div className="mt-3 p-4 bg-light-blue/20 rounded-lg border border-light-blue/30">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <FileVideo className="text-light-blue" size={20} />
                            <div>
                              <span className="text-sm text-text-light font-medium block">
                                {selectedFile.name}
                              </span>
                              <span className="text-xs text-gray-400">
                                {(selectedFile.size / 1024 / 1024).toFixed(1)} MB • {selectedFile.type}
                              </span>
                            </div>
                          </div>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setSelectedFile(null)}
                            className="border-red-500 text-red-400 hover:bg-red-500 hover:text-white"
                          >
                            Remove
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Upload Progress Simulation */}
                  {selectedFile && (
                    <div className="bg-deep-dark p-4 rounded-lg border border-gray-700">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-text-light">Upload Progress</span>
                        <span className="text-sm text-gray-400">Ready to upload</span>
                      </div>
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <div className="bg-light-blue h-2 rounded-full w-0 transition-all duration-300" />
                      </div>
                      <p className="text-xs text-gray-500 mt-2">
                        File will be uploaded when you save the video details
                      </p>
                    </div>
                  )}
                </div>
              )}
              <div>
                <Label htmlFor="title" className="text-base font-medium">Episode Title *</Label>
                <Input
                  id="title"
                  name="title"
                  defaultValue={editingVideo?.title || ""}
                  required
                  className="bg-deep-dark border-gray-700 mt-2"
                  placeholder="Enter your episode or video title"
                />
                <p className="text-xs text-gray-500 mt-1">
                  This will be displayed as the main title for your content
                </p>
              </div>
              
              <div>
                <Label htmlFor="description" className="text-base font-medium">Episode Description</Label>
                <Textarea
                  id="description"
                  name="description"
                  defaultValue={editingVideo?.description || ""}
                  className="bg-deep-dark border-gray-700 mt-2"
                  rows={4}
                  placeholder="Describe what this episode covers, key topics discussed, guest information, etc."
                />
                <p className="text-xs text-gray-500 mt-1">
                  Help your audience understand what they'll learn or hear in this episode
                </p>
              </div>

              {/* Thumbnail Upload */}
              <div>
                <Label className="text-base font-medium">Episode Thumbnail</Label>
                <p className="text-xs text-gray-500 mb-3">
                  Upload a custom thumbnail or provide a URL (recommended: 1280x720)
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="thumbnailFile" className="text-sm">Upload Thumbnail</Label>
                    <FileUpload 
                      onFileSelect={(file) => {
                        // Handle thumbnail file
                        toast({
                          title: "Thumbnail Selected",
                          description: `${file.name} will be used as thumbnail`,
                        });
                      }}
                      acceptedTypes="image/*,.jpg,.jpeg,.png,.webp"
                      maxSize={5}
                      preview={true}
                    />
                  </div>
                  <div>
                    <Label htmlFor="thumbnail" className="text-sm">Or Enter Thumbnail URL</Label>
                    <Input
                      id="thumbnail"
                      name="thumbnail"
                      type="url"
                      defaultValue={editingVideo?.thumbnail || ""}
                      className="bg-deep-dark border-gray-700 mt-2"
                      placeholder="https://example.com/thumbnail.jpg"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Leave empty to auto-generate from video
                    </p>
                  </div>
                </div>
              </div>

              {/* Video URL or File Reference */}
              <div>
                <Label htmlFor="videoUrl" className="text-base font-medium">Video URL (Optional)</Label>
                <Input
                  id="videoUrl"
                  name="videoUrl"
                  type="url"
                  defaultValue={editingVideo?.videoUrl || ""}
                  className="bg-deep-dark border-gray-700 mt-2"
                  placeholder="https://youtube.com/watch?v=... or direct video URL"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Link to external video (YouTube, Vimeo) or leave empty if uploading file above
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="duration" className="text-base font-medium">Episode Duration</Label>
                  <Input
                    id="duration"
                    name="duration"
                    placeholder="45:30 or 1:23:45"
                    defaultValue={editingVideo?.duration || ""}
                    className="bg-deep-dark border-gray-700 mt-2"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Format: MM:SS or H:MM:SS
                  </p>
                </div>
                
                <div>
                  <Label htmlFor="category" className="text-base font-medium">Episode Category</Label>
                  <Select name="category" defaultValue={editingVideo?.category || ""}>
                    <SelectTrigger className="bg-deep-dark border-gray-700 mt-2">
                      <SelectValue placeholder="Choose category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="street-smarts">Street Smarts</SelectItem>
                      <SelectItem value="bad-decisions">Bad Decisions</SelectItem>
                      <SelectItem value="general">General Discussion</SelectItem>
                      <SelectItem value="interview">Guest Interview</SelectItem>
                      <SelectItem value="behind-scenes">Behind the Scenes</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="publishDate" className="text-base font-medium">Publish Date</Label>
                  <Input
                    id="publishDate"
                    name="publishDate"
                    type="datetime-local"
                    className="bg-deep-dark border-gray-700 mt-2"
                    defaultValue={new Date().toISOString().slice(0, 16)}
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    When to make this episode public
                  </p>
                </div>
              </div>

              {/* Additional Episode Details */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="tags" className="text-base font-medium">Tags (Optional)</Label>
                  <Input
                    id="tags"
                    name="tags"
                    placeholder="photography, urban, street art"
                    className="bg-deep-dark border-gray-700 mt-2"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Separate tags with commas for better organization
                  </p>
                </div>

                <div>
                  <Label htmlFor="guestName" className="text-base font-medium">Guest Name (Optional)</Label>
                  <Input
                    id="guestName"
                    name="guestName"
                    placeholder="Featured guest or co-host"
                    className="bg-deep-dark border-gray-700 mt-2"
                  />
                </div>
              </div>

              {/* Form Actions */}
              <div className="flex justify-between items-center pt-6 border-t border-gray-700">
                <div className="flex items-center space-x-3">
                  {editingVideo && (
                    <Button 
                      type="button"
                      variant="outline"
                      onClick={() => handleDuplicate(editingVideo)}
                      className="border-light-blue text-light-blue hover:bg-light-blue hover:text-white"
                    >
                      <Copy className="mr-2" size={16} />
                      Duplicate Episode
                    </Button>
                  )}
                  <div className="text-xs text-gray-500">
                    {selectedFile && !editingVideo && (
                      <span className="flex items-center">
                        <FileVideo className="mr-1" size={12} />
                        File ready: {selectedFile.name}
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex space-x-3">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => {
                      setIsDialogOpen(false);
                      setSelectedFile(null);
                    }}
                    className="border-gray-600"
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit" 
                    className="bg-light-blue hover:bg-accent-blue px-6"
                    disabled={createMutation.isPending || updateMutation.isPending || (!editingVideo && !selectedFile)}
                  >
                    {createMutation.isPending || updateMutation.isPending ? (
                      <>
                        <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                        {editingVideo ? "Updating..." : "Creating..."}
                      </>
                    ) : (
                      <>
                        <Upload className="mr-2" size={16} />
                        {editingVideo ? "Update Episode" : "Create Episode"}
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </form>
          </DialogContent>
        </Dialog>
        </div>
      </div>

      {/* Search and Filter Controls */}
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
            <input
              type="text"
              placeholder="Search videos by title or description..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-dark-surface border border-gray-700 rounded-lg text-text-light focus:border-light-blue focus:ring-1 focus:ring-light-blue"
            />
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <Filter className="text-gray-400" size={16} />
          <Select value={filterCategory} onValueChange={setFilterCategory}>
            <SelectTrigger className="bg-dark-surface border-gray-700 w-48">
              <SelectValue placeholder="Filter by category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              <SelectItem value="street-smarts">Street Smarts</SelectItem>
              <SelectItem value="bad-decisions">Bad Decisions</SelectItem>
              <SelectItem value="general">General</SelectItem>
            </SelectContent>
          </Select>
          <Badge variant="outline" className="border-light-blue text-light-blue">
            {filteredVideos.length} videos
          </Badge>
        </div>
      </div>

      {/* Videos Grid */}
      {filteredVideos && filteredVideos.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredVideos.map((video) => (
            <Card key={video.id} className="bg-dark-surface overflow-hidden">
              <div className="aspect-video relative">
                <img 
                  src={video.thumbnail || "https://images.unsplash.com/photo-1516280440614-37939bbacd81?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=338"} 
                  alt={video.title} 
                  className="w-full h-full object-cover"
                />
                {video.duration && (
                  <span className="absolute bottom-2 right-2 bg-black/70 px-2 py-1 rounded text-sm text-white">
                    {video.duration}
                  </span>
                )}
                <div className="absolute top-2 right-2 flex space-x-1">
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-8 w-8 p-0 bg-black/50 border-white/20"
                    onClick={() => handleEdit(video)}
                  >
                    <Edit size={14} />
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-8 w-8 p-0 bg-black/50 border-white/20 hover:bg-red-500"
                    onClick={() => handleDelete(video.id)}
                  >
                    <Trash2 size={14} />
                  </Button>
                </div>
              </div>
              <CardContent className="p-4">
                <h3 className="font-semibold text-text-light mb-2 line-clamp-2">{video.title}</h3>
                {video.description && (
                  <p className="text-gray-400 text-sm mb-3 line-clamp-2">{video.description}</p>
                )}
                <div className="flex items-center justify-between text-xs text-gray-500">
                  <div className="flex items-center">
                    <Calendar size={12} className="mr-1" />
                    {video.createdAt ? new Date(video.createdAt).toLocaleDateString() : 'Recently'}
                  </div>
                  {video.category && (
                    <span className="bg-light-blue/20 text-light-blue px-2 py-1 rounded">
                      {video.category}
                    </span>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="bg-dark-surface">
          <CardContent className="p-12 text-center">
            <div className="w-24 h-24 bg-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Video className="text-blue-400" size={48} />
            </div>
            <h3 className="text-xl font-semibold text-text-light mb-2">No videos yet</h3>
            <p className="text-gray-400 mb-6 max-w-md mx-auto">
              Start building your video library by adding your first podcast episode or video content.
            </p>
            <Button onClick={openNewVideoDialog} className="bg-light-blue hover:bg-accent-blue">
              <Plus className="mr-2" size={16} />
              Add Your First Video
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}