import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Eye, 
  Edit, 
  Smartphone, 
  Monitor, 
  Tablet,
  Save,
  Undo,
  Redo,
  Type,
  Image,
  Layout,
  Palette
} from "lucide-react";

interface VisualEditorProps {
  page: string;
  onSave: (content: any) => void;
}

export default function VisualEditor({ page, onSave }: VisualEditorProps) {
  const [previewMode, setPreviewMode] = useState<"desktop" | "tablet" | "mobile">("desktop");
  const [editMode, setEditMode] = useState(false);
  
  const [content, setContent] = useState({
    hero: {
      title: "Street Smarts & Bad Decisions",
      subtitle: "Where wisdom meets chaos in the digital age",
      backgroundImage: "https://images.unsplash.com/photo-1516280440614-37939bbacd81?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=800",
      showButton: true,
      buttonText: "Listen Now",
      buttonUrl: "/videos"
    },
    sections: [
      {
        id: "featured",
        type: "featured-content",
        title: "Featured Episodes",
        visible: true
      },
      {
        id: "gallery",
        type: "photo-grid",
        title: "Photography",
        visible: true
      },
      {
        id: "community",
        type: "forum-preview",
        title: "Community Discussions",
        visible: true
      }
    ]
  });

  const getPreviewWidth = () => {
    switch (previewMode) {
      case "mobile": return "375px";
      case "tablet": return "768px";
      default: return "100%";
    }
  };

  return (
    <div className="space-y-6">
      {/* Editor Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-text-light">Visual Page Editor</h2>
          <p className="text-gray-400">Edit your {page} page with live preview</p>
        </div>
        <div className="flex items-center space-x-4">
          {/* Preview Mode Switcher */}
          <div className="flex items-center space-x-2 bg-dark-surface rounded-lg p-1">
            <Button
              size="sm"
              variant={previewMode === "desktop" ? "default" : "ghost"}
              onClick={() => setPreviewMode("desktop")}
              className="p-2"
            >
              <Monitor size={16} />
            </Button>
            <Button
              size="sm"
              variant={previewMode === "tablet" ? "default" : "ghost"}
              onClick={() => setPreviewMode("tablet")}
              className="p-2"
            >
              <Tablet size={16} />
            </Button>
            <Button
              size="sm"
              variant={previewMode === "mobile" ? "default" : "ghost"}
              onClick={() => setPreviewMode("mobile")}
              className="p-2"
            >
              <Smartphone size={16} />
            </Button>
          </div>

          {/* Edit Mode Toggle */}
          <Button
            variant={editMode ? "default" : "outline"}
            onClick={() => setEditMode(!editMode)}
            className="bg-light-blue hover:bg-accent-blue"
          >
            <Edit className="mr-2" size={16} />
            {editMode ? "Exit Edit" : "Edit Mode"}
          </Button>

          <Button onClick={() => onSave(content)} className="bg-green-600 hover:bg-green-500">
            <Save className="mr-2" size={16} />
            Save Changes
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Settings Panel */}
        {editMode && (
          <div className="lg:col-span-1 space-y-4">
            <Card className="bg-dark-surface">
              <CardHeader>
                <CardTitle className="text-text-light text-lg">Edit Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Tabs defaultValue="hero" className="w-full">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="hero">Hero</TabsTrigger>
                    <TabsTrigger value="sections">Sections</TabsTrigger>
                    <TabsTrigger value="style">Style</TabsTrigger>
                  </TabsList>

                  <TabsContent value="hero" className="space-y-4">
                    <div>
                      <Label>Hero Title</Label>
                      <Input
                        value={content.hero.title}
                        onChange={(e) => setContent({
                          ...content,
                          hero: { ...content.hero, title: e.target.value }
                        })}
                        className="bg-deep-dark border-gray-700"
                      />
                    </div>
                    <div>
                      <Label>Hero Subtitle</Label>
                      <Textarea
                        value={content.hero.subtitle}
                        onChange={(e) => setContent({
                          ...content,
                          hero: { ...content.hero, subtitle: e.target.value }
                        })}
                        className="bg-deep-dark border-gray-700"
                        rows={2}
                      />
                    </div>
                    <div>
                      <Label>Background Image URL</Label>
                      <Input
                        value={content.hero.backgroundImage}
                        onChange={(e) => setContent({
                          ...content,
                          hero: { ...content.hero, backgroundImage: e.target.value }
                        })}
                        className="bg-deep-dark border-gray-700"
                      />
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={content.hero.showButton}
                        onCheckedChange={(checked) => setContent({
                          ...content,
                          hero: { ...content.hero, showButton: checked }
                        })}
                      />
                      <Label>Show Call-to-Action Button</Label>
                    </div>
                    {content.hero.showButton && (
                      <>
                        <div>
                          <Label>Button Text</Label>
                          <Input
                            value={content.hero.buttonText}
                            onChange={(e) => setContent({
                              ...content,
                              hero: { ...content.hero, buttonText: e.target.value }
                            })}
                            className="bg-deep-dark border-gray-700"
                          />
                        </div>
                        <div>
                          <Label>Button Link</Label>
                          <Input
                            value={content.hero.buttonUrl}
                            onChange={(e) => setContent({
                              ...content,
                              hero: { ...content.hero, buttonUrl: e.target.value }
                            })}
                            className="bg-deep-dark border-gray-700"
                          />
                        </div>
                      </>
                    )}
                  </TabsContent>

                  <TabsContent value="sections" className="space-y-4">
                    {content.sections.map((section, index) => (
                      <div key={section.id} className="p-3 bg-deep-dark rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-medium text-text-light">{section.title}</span>
                          <Switch
                            checked={section.visible}
                            onCheckedChange={(checked) => {
                              const newSections = [...content.sections];
                              newSections[index].visible = checked;
                              setContent({ ...content, sections: newSections });
                            }}
                          />
                        </div>
                        <p className="text-xs text-gray-400 capitalize">{section.type.replace('-', ' ')}</p>
                      </div>
                    ))}
                  </TabsContent>

                  <TabsContent value="style" className="space-y-4">
                    <div>
                      <Label>Primary Color</Label>
                      <Input
                        type="color"
                        defaultValue="#3B82F6"
                        className="bg-deep-dark border-gray-700 h-12"
                      />
                    </div>
                    <div>
                      <Label>Text Size</Label>
                      <select className="w-full bg-deep-dark border border-gray-700 rounded p-2 text-text-light">
                        <option>Small</option>
                        <option selected>Medium</option>
                        <option>Large</option>
                      </select>
                    </div>
                    <div>
                      <Label>Layout Spacing</Label>
                      <select className="w-full bg-deep-dark border border-gray-700 rounded p-2 text-text-light">
                        <option>Compact</option>
                        <option selected>Normal</option>
                        <option>Spacious</option>
                      </select>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Live Preview */}
        <div className={editMode ? "lg:col-span-3" : "lg:col-span-4"}>
          <Card className="bg-dark-surface">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="text-text-light flex items-center">
                  <Eye className="mr-2 text-accent-blue" size={20} />
                  Live Preview ({previewMode})
                </CardTitle>
                <div className="flex items-center space-x-2 text-sm text-gray-400">
                  <span>{getPreviewWidth()}</span>
                  {previewMode !== "desktop" && <span>responsive</span>}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div 
                className="bg-black rounded-lg overflow-hidden border border-gray-700 mx-auto transition-all duration-300"
                style={{ width: getPreviewWidth(), maxWidth: "100%" }}
              >
                {/* Hero Section Preview */}
                <div 
                  className="relative h-64 md:h-80 bg-cover bg-center flex items-center justify-center"
                  style={{ backgroundImage: `url(${content.hero.backgroundImage})` }}
                >
                  <div className="absolute inset-0 bg-black/50" />
                  <div className="relative text-center text-white p-6">
                    <h1 className="text-2xl md:text-4xl font-bold mb-4">
                      {content.hero.title}
                    </h1>
                    <p className="text-lg md:text-xl mb-6 opacity-90">
                      {content.hero.subtitle}
                    </p>
                    {content.hero.showButton && (
                      <Button className="bg-light-blue hover:bg-accent-blue">
                        {content.hero.buttonText}
                      </Button>
                    )}
                  </div>
                  {editMode && (
                    <div className="absolute top-2 right-2">
                      <Button size="sm" variant="outline" className="bg-black/50 border-white/20">
                        <Edit size={14} />
                      </Button>
                    </div>
                  )}
                </div>

                {/* Sections Preview */}
                <div className="p-6 space-y-8">
                  {content.sections.filter(s => s.visible).map((section) => (
                    <div key={section.id} className="relative">
                      {editMode && (
                        <div className="absolute top-0 right-0 -mt-2 -mr-2">
                          <Button size="sm" variant="outline" className="bg-dark-surface border-gray-600">
                            <Edit size={12} />
                          </Button>
                        </div>
                      )}
                      <h2 className="text-xl font-bold text-text-light mb-4">{section.title}</h2>
                      
                      {section.type === "featured-content" && (
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          {[1, 2, 3].map((i) => (
                            <div key={i} className="bg-deep-dark rounded-lg p-4">
                              <div className="w-full h-32 bg-gray-700 rounded mb-3" />
                              <h3 className="font-semibold text-text-light">Episode {i}</h3>
                              <p className="text-sm text-gray-400">Your episode description will appear here...</p>
                            </div>
                          ))}
                        </div>
                      )}
                      
                      {section.type === "photo-grid" && (
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                          {[1, 2, 3, 4].map((i) => (
                            <div key={i} className="aspect-square bg-gray-700 rounded-lg" />
                          ))}
                        </div>
                      )}
                      
                      {section.type === "forum-preview" && (
                        <div className="space-y-3">
                          {[1, 2, 3].map((i) => (
                            <div key={i} className="bg-deep-dark rounded-lg p-4 flex items-start space-x-3">
                              <div className="w-8 h-8 bg-light-blue rounded-full" />
                              <div className="flex-1">
                                <h4 className="font-medium text-text-light">Discussion Topic {i}</h4>
                                <p className="text-sm text-gray-400">Recent community discussion...</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}