import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { 
  Plus, 
  Upload, 
  Edit, 
  Trash2, 
  Download, 
  Copy, 
  Settings,
  Video,
  Camera,
  MessageCircle,
  Users,
  FileText,
  Palette,
  Link,
  FolderOpen
} from "lucide-react";

interface QuickActionsProps {
  onVideoCreate: () => void;
  onPhotoUpload: () => void;
  onForumModerate: () => void;
  onCommentManage: () => void;
  onSettingsOpen: () => void;
  onFilesManage?: () => void;
  onTextEdit?: () => void;
}

export default function QuickActions({ 
  onVideoCreate, 
  onPhotoUpload, 
  onForumModerate, 
  onCommentManage,
  onSettingsOpen,
  onFilesManage,
  onTextEdit
}: QuickActionsProps) {
  const { toast } = useToast();
  const actions = [
    {
      title: "Create Video",
      description: "Add new podcast episode",
      icon: Video,
      color: "bg-light-blue",
      hoverColor: "hover:bg-accent-blue",
      action: onVideoCreate
    },
    {
      title: "Upload Photos",
      description: "Add to gallery",
      icon: Camera,
      color: "bg-light-blue",
      hoverColor: "hover:bg-accent-blue",
      action: onPhotoUpload
    },
    {
      title: "Moderate Forum",
      description: "Review posts",
      icon: MessageCircle,
      color: "bg-light-blue",
      hoverColor: "hover:bg-accent-blue",
      action: onForumModerate
    },
    {
      title: "Manage Comments",
      description: "Control user feedback",
      icon: Users,
      color: "bg-light-blue",
      hoverColor: "hover:bg-accent-blue",
      action: onCommentManage
    },
    {
      title: "Manage Files",
      description: "Upload & organize",
      icon: FolderOpen,
      color: "bg-light-blue",
      hoverColor: "hover:bg-accent-blue",
      action: onFilesManage || (() => {})
    },
    {
      title: "Edit Text",
      description: "Change all phrases",
      icon: FileText,
      color: "bg-light-blue",
      hoverColor: "hover:bg-accent-blue", 
      action: onTextEdit || (() => {})
    },
    {
      title: "Site Settings",
      description: "Customize appearance",
      icon: Settings,
      color: "bg-light-blue",
      hoverColor: "hover:bg-accent-blue",
      action: onSettingsOpen
    }
  ];

  const contentActions = [
    {
      title: "Bulk Upload",
      icon: Upload,
      description: "Upload multiple files at once"
    },
    {
      title: "Export Data",
      icon: Download,
      description: "Download your content"
    },
    {
      title: "Duplicate Content",
      icon: Copy,
      description: "Clone existing items"
    },
    {
      title: "Edit Templates",
      icon: Edit,
      description: "Customize page layouts"
    }
  ];

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Mobile-Responsive Primary Actions */}
      <Card className="bg-dark-surface">
        <CardHeader>
          <CardTitle className="text-text-light text-lg sm:text-xl">Quick Actions for Malissa</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-7 gap-2 sm:gap-4">
            {actions.map((action, index) => (
              <Button
                key={index}
                onClick={() => {
                  console.log(`Quick action clicked: ${action.title}`);
                  action.action();
                }}
                className={`${action.color} ${action.hoverColor} text-white p-3 sm:p-6 h-auto flex flex-col items-center space-y-1 sm:space-y-3 transition-all duration-200 transform hover:scale-105`}
              >
                <action.icon size={24} className="sm:w-8 sm:h-8" />
                <div className="text-center">
                  <div className="font-semibold text-xs sm:text-sm">{action.title}</div>
                  <div className="text-xs opacity-90 hidden sm:block">{action.description}</div>
                </div>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Content Management Actions */}
      <Card className="bg-dark-surface">
        <CardHeader>
          <CardTitle className="text-text-light">Content Management Tools</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {contentActions.map((action, index) => (
              <Button
                key={index}
                variant="outline"
                className="p-4 bg-deep-dark rounded-lg border border-gray-700 hover:border-light-blue transition-colors h-auto justify-start"
                onClick={() => {
                  console.log(`Content action clicked: ${action.title}`);
                  // Handle content action clicks with immediate action
                  if (action.title === "Bulk Upload") {
                    onFilesManage?.();
                  } else if (action.title === "Export Data") {
                    // Add export functionality
                    window.open('/api/export', '_blank');
                  } else if (action.title === "Duplicate Content") {
                    onVideoCreate?.();
                  } else if (action.title === "Edit Templates") {
                    onTextEdit?.();
                  }
                }}
              >
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-light-blue/20 rounded-lg flex items-center justify-center">
                    <action.icon className="text-light-blue" size={20} />
                  </div>
                  <div className="text-left">
                    <h4 className="font-medium text-text-light text-xs sm:text-sm">{action.title}</h4>
                    <p className="text-xs text-gray-400 hidden sm:block">{action.description}</p>
                  </div>
                </div>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* File Management */}
      <Card className="bg-dark-surface">
        <CardHeader>
          <CardTitle className="text-text-light">File Management</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-deep-dark rounded-lg p-4 border border-gray-700">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-medium text-text-light">Video Files</h4>
                <Button 
                  size="sm" 
                  className="bg-light-blue hover:bg-accent-blue"
                  onClick={() => {
                    console.log('Video upload button clicked');
                    onVideoCreate?.();
                  }}
                >
                  <Upload size={14} className="mr-1" />
                  Upload
                </Button>
              </div>
              <div className="space-y-2 text-sm text-gray-400">
                <div className="flex justify-between">
                  <span>Total Videos:</span>
                  <span className="text-text-light">0</span>
                </div>
                <div className="flex justify-between">
                  <span>Storage Used:</span>
                  <span className="text-text-light">0 MB</span>
                </div>
              </div>
            </div>

            <div className="bg-deep-dark rounded-lg p-4 border border-gray-700">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-medium text-text-light">Photos</h4>
                <Button 
                  size="sm" 
                  className="bg-light-blue hover:bg-accent-blue"
                  onClick={() => {
                    console.log('Photo upload button clicked');
                    onPhotoUpload?.();
                  }}
                >
                  <Upload size={14} className="mr-1" />
                  Upload
                </Button>
              </div>
              <div className="space-y-2 text-sm text-gray-400">
                <div className="flex justify-between">
                  <span>Total Photos:</span>
                  <span className="text-text-light">0</span>
                </div>
                <div className="flex justify-between">
                  <span>Storage Used:</span>
                  <span className="text-text-light">0 MB</span>
                </div>
              </div>
            </div>

            <div className="bg-deep-dark rounded-lg p-4 border border-gray-700">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-medium text-text-light">Documents</h4>
                <Button 
                  size="sm" 
                  className="bg-light-blue hover:bg-accent-blue"
                  onClick={() => {
                    console.log('Documents upload button clicked');
                    onFilesManage?.();
                  }}
                >
                  <Upload size={14} className="mr-1" />
                  Upload
                </Button>
              </div>
              <div className="space-y-2 text-sm text-gray-400">
                <div className="flex justify-between">
                  <span>Total Files:</span>
                  <span className="text-text-light">0</span>
                </div>
                <div className="flex justify-between">
                  <span>Storage Used:</span>
                  <span className="text-text-light">0 MB</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}