import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { 
  MessageCircle, 
  Trash2, 
  Calendar,
  User,
  Reply,
  AlertTriangle
} from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { ForumPost } from "@shared/schema";

export default function AdminForum() {
  const { toast } = useToast();

  const { data: forumPosts, isLoading } = useQuery<ForumPost[]>({
    queryKey: ["/api/forum"],
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("DELETE", `/api/forum/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/forum"] });
      toast({
        title: "Success",
        description: "Forum post deleted successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete forum post. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleDelete = (id: number, title: string) => {
    if (confirm(`Are you sure you want to delete the post "${title}"?`)) {
      deleteMutation.mutate(id);
    }
  };

  const getCategoryColor = (category: string | null) => {
    switch (category) {
      case "street-smarts": return "bg-green-500/20 text-green-400";
      case "bad-decisions": return "bg-red-500/20 text-red-400";
      case "photography": return "bg-blue-500/20 text-blue-400";
      default: return "bg-gray-500/20 text-gray-400";
    }
  };

  const getCategoryName = (category: string | null) => {
    switch (category) {
      case "street-smarts": return "Street Smarts";
      case "bad-decisions": return "Bad Decision";
      case "photography": return "Photography";
      default: return "General";
    }
  };

  const getInitials = (username: string) => {
    return username.split('_').map(word => word[0]).join('').toUpperCase().slice(0, 2);
  };

  const formatTime = (date: Date | string | null) => {
    if (!date) return 'Recently';
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    const now = new Date();
    const diff = now.getTime() - dateObj.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(hours / 24);

    if (days > 0) return `${days} day${days > 1 ? 's' : ''} ago`;
    if (hours > 0) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    return 'Just now';
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <Skeleton className="h-8 w-48" />
        </div>
        <div className="space-y-4">
          {[...Array(5)].map((_, i) => (
            <Card key={i} className="bg-dark-surface">
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <Skeleton className="h-12 w-12 rounded-full" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-6 w-3/4" />
                    <Skeleton className="h-16 w-full" />
                    <div className="flex items-center space-x-4">
                      <Skeleton className="h-4 w-24" />
                      <Skeleton className="h-4 w-16" />
                      <Skeleton className="h-4 w-20" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-text-light">Forum Management</h2>
          <p className="text-gray-400">Moderate community discussions and forum posts</p>
        </div>
        <div className="flex items-center space-x-4">
          <Badge variant="outline" className="border-green-500 text-green-400">
            {forumPosts?.length || 0} Total Posts
          </Badge>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-dark-surface">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-400">
              {forumPosts?.filter(p => p.category === "street-smarts").length || 0}
            </div>
            <div className="text-sm text-gray-400">Street Smarts</div>
          </CardContent>
        </Card>
        <Card className="bg-dark-surface">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-red-400">
              {forumPosts?.filter(p => p.category === "bad-decisions").length || 0}
            </div>
            <div className="text-sm text-gray-400">Bad Decisions</div>
          </CardContent>
        </Card>
        <Card className="bg-dark-surface">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-400">
              {forumPosts?.filter(p => p.category === "photography").length || 0}
            </div>
            <div className="text-sm text-gray-400">Photography</div>
          </CardContent>
        </Card>
        <Card className="bg-dark-surface">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-purple-400">
              {forumPosts?.reduce((sum, post) => sum + (post.replies || 0), 0) || 0}
            </div>
            <div className="text-sm text-gray-400">Total Replies</div>
          </CardContent>
        </Card>
      </div>

      {/* Forum Posts */}
      {forumPosts && forumPosts.length > 0 ? (
        <div className="space-y-4">
          {forumPosts.map((post) => (
            <Card key={post.id} className="bg-dark-surface">
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-light-blue to-accent-blue rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0">
                    {getInitials(post.author)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold text-text-light">{post.title}</h3>
                          {post.category && (
                            <Badge className={getCategoryColor(post.category)}>
                              {getCategoryName(post.category)}
                            </Badge>
                          )}
                        </div>
                        <p className="text-gray-400 text-sm mb-3">{post.content}</p>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-red-500 text-red-400 hover:bg-red-500 hover:text-white ml-4"
                        onClick={() => handleDelete(post.id, post.title)}
                        disabled={deleteMutation.isPending}
                      >
                        <Trash2 size={14} />
                      </Button>
                    </div>
                    <div className="flex items-center space-x-4 text-xs text-gray-500">
                      <div className="flex items-center">
                        <User size={12} className="mr-1" />
                        {post.author}
                      </div>
                      <div className="flex items-center">
                        <Calendar size={12} className="mr-1" />
                        {formatTime(post.createdAt)}
                      </div>
                      <div className="flex items-center">
                        <Reply size={12} className="mr-1" />
                        {post.replies || 0} replies
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="bg-dark-surface">
          <CardContent className="p-12 text-center">
            <div className="w-24 h-24 bg-purple-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <MessageCircle className="text-purple-400" size={48} />
            </div>
            <h3 className="text-xl font-semibold text-text-light mb-2">No forum posts yet</h3>
            <p className="text-gray-400 mb-6 max-w-md mx-auto">
              Community discussions will appear here once users start posting in the forum.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Moderation Guidelines */}
      <Card className="bg-dark-surface border-amber-500/30">
        <CardHeader>
          <CardTitle className="text-text-light flex items-center">
            <AlertTriangle className="mr-2 text-amber-400" size={20} />
            Moderation Guidelines
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4 text-sm text-gray-400">
            <div>
              <h4 className="font-semibold text-text-light mb-2">Delete posts that contain:</h4>
              <ul className="space-y-1">
                <li>• Spam or promotional content</li>
                <li>• Inappropriate or offensive language</li>
                <li>• Personal attacks or harassment</li>
                <li>• Off-topic discussions</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-text-light mb-2">Encourage posts that:</h4>
              <ul className="space-y-1">
                <li>• Share valuable experiences</li>
                <li>• Ask thoughtful questions</li>
                <li>• Provide helpful advice</li>
                <li>• Foster community discussion</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}