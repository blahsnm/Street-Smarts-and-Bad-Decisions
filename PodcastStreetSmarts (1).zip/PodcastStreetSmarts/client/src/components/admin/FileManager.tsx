import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { 
  Upload, 
  File, 
  Image, 
  Video, 
  Music, 
  FileText,
  Trash2,
  Download,
  Eye,
  Edit,
  Folder,
  Plus
} from "lucide-react";
import FileUpload from "@/components/admin/FileUpload";
import BulkActions from "@/components/admin/BulkActions";

interface FileItem {
  id: string;
  name: string;
  type: 'image' | 'video' | 'audio' | 'document';
  size: string;
  url: string;
  uploadDate: string;
}

export default function FileManager() {
  const [files, setFiles] = useState<FileItem[]>([
    {
      id: '1',
      name: 'episode-001-thumbnail.jpg',
      type: 'image',
      size: '245 KB',
      url: 'https://example.com/thumb1.jpg',
      uploadDate: '2025-01-06'
    },
    {
      id: '2', 
      name: 'street-photo-collection.mp4',
      type: 'video',
      size: '125 MB',
      url: 'https://example.com/video1.mp4',
      uploadDate: '2025-01-05'
    }
  ]);
  
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<string[]>([]);
  const { toast } = useToast();

  const getFileIcon = (type: string) => {
    switch (type) {
      case 'image': return <Image className="text-green-400" size={20} />;
      case 'video': return <Video className="text-blue-400" size={20} />;
      case 'audio': return <Music className="text-purple-400" size={20} />;
      case 'document': return <FileText className="text-yellow-400" size={20} />;
      default: return <File className="text-gray-400" size={20} />;
    }
  };

  const handleFileUpload = (file: File) => {
    const newFile: FileItem = {
      id: Date.now().toString(),
      name: file.name,
      type: file.type.startsWith('image/') ? 'image' : 
            file.type.startsWith('video/') ? 'video' :
            file.type.startsWith('audio/') ? 'audio' : 'document',
      size: `${(file.size / 1024 / 1024).toFixed(1)} MB`,
      url: URL.createObjectURL(file),
      uploadDate: new Date().toISOString().split('T')[0]
    };
    
    setFiles([newFile, ...files]);
    setIsUploadOpen(false);
    
    toast({
      title: "File Uploaded",
      description: `${file.name} has been uploaded successfully!`,
    });
  };

  const handleDelete = (fileId: string) => {
    const file = files.find(f => f.id === fileId);
    if (file && confirm(`Delete ${file.name}?`)) {
      setFiles(files.filter(f => f.id !== fileId));
      toast({
        title: "File Deleted",
        description: "File has been removed from your library",
      });
    }
  };

  const handleBulkDelete = () => {
    if (selectedFiles.length > 0 && confirm(`Delete ${selectedFiles.length} selected files?`)) {
      setFiles(files.filter(f => !selectedFiles.includes(f.id)));
      setSelectedFiles([]);
      toast({
        title: "Files Deleted",
        description: `${selectedFiles.length} files have been removed`,
      });
    }
  };

  const toggleFileSelection = (fileId: string) => {
    if (selectedFiles.includes(fileId)) {
      setSelectedFiles(selectedFiles.filter(id => id !== fileId));
    } else {
      setSelectedFiles([...selectedFiles, fileId]);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-text-light">File Manager</h2>
          <p className="text-gray-400">Upload and manage all your media files, Malissa</p>
        </div>
        <div className="flex items-center space-x-3">
          {selectedFiles.length > 0 && (
            <Button 
              onClick={handleBulkDelete}
              variant="outline"
              className="border-red-500 text-red-400 hover:bg-red-500 hover:text-white"
            >
              <Trash2 className="mr-2" size={16} />
              Delete Selected ({selectedFiles.length})
            </Button>
          )}
          <Dialog open={isUploadOpen} onOpenChange={setIsUploadOpen}>
            <DialogTrigger asChild>
              <Button className="bg-light-blue hover:bg-accent-blue">
                <Upload className="mr-2" size={16} />
                Upload Files
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-dark-surface text-text-light max-w-2xl">
              <DialogHeader>
                <DialogTitle>Upload New Files</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <FileUpload 
                  onFileSelect={handleFileUpload}
                  acceptedTypes="image/*,video/*,audio/*,.pdf,.doc,.docx,.txt"
                  maxSize={100}
                  preview={true}
                />
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                  <div className="text-center p-4 bg-deep-dark rounded-lg">
                    <Image className="text-green-400 mx-auto mb-2" size={24} />
                    <p className="text-sm text-text-light">Images</p>
                    <p className="text-xs text-gray-400">JPG, PNG, GIF</p>
                  </div>
                  <div className="text-center p-4 bg-deep-dark rounded-lg">
                    <Video className="text-blue-400 mx-auto mb-2" size={24} />
                    <p className="text-sm text-text-light">Videos</p>
                    <p className="text-xs text-gray-400">MP4, MOV, AVI</p>
                  </div>
                  <div className="text-center p-4 bg-deep-dark rounded-lg">
                    <Music className="text-purple-400 mx-auto mb-2" size={24} />
                    <p className="text-sm text-text-light">Audio</p>
                    <p className="text-xs text-gray-400">MP3, WAV, AAC</p>
                  </div>
                  <div className="text-center p-4 bg-deep-dark rounded-lg">
                    <FileText className="text-yellow-400 mx-auto mb-2" size={24} />
                    <p className="text-sm text-text-light">Documents</p>
                    <p className="text-xs text-gray-400">PDF, DOC, TXT</p>
                  </div>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* File Type Filters */}
      <Card className="bg-dark-surface">
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-2">
            {['all', 'image', 'video', 'audio', 'document'].map((type) => (
              <Button
                key={type}
                size="sm"
                variant="outline"
                className="border-gray-600 hover:border-light-blue hover:text-light-blue"
              >
                {type === 'all' ? <Folder size={14} className="mr-1" /> : getFileIcon(type)}
                <span className="ml-1 capitalize">{type} Files</span>
                <span className="ml-2 text-xs bg-gray-700 px-2 py-1 rounded">
                  {type === 'all' ? files.length : files.filter(f => f.type === type).length}
                </span>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Files Grid */}
      {files.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {files.map((file) => (
            <Card key={file.id} className="bg-dark-surface hover:bg-gray-800 transition-colors">
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center space-x-2">
                    {getFileIcon(file.type)}
                    <input
                      type="checkbox"
                      checked={selectedFiles.includes(file.id)}
                      onChange={() => toggleFileSelection(file.id)}
                      className="w-4 h-4 text-light-blue bg-deep-dark border-gray-600 rounded focus:ring-light-blue"
                    />
                  </div>
                  <div className="flex items-center space-x-1">
                    <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                      <Eye size={14} />
                    </Button>
                    <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                      <Download size={14} />
                    </Button>
                    <Button size="sm" variant="ghost" className="h-8 w-8 p-0">
                      <Edit size={14} />
                    </Button>
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      className="h-8 w-8 p-0 hover:text-red-400"
                      onClick={() => handleDelete(file.id)}
                    >
                      <Trash2 size={14} />
                    </Button>
                  </div>
                </div>

                {file.type === 'image' && (
                  <div className="aspect-square bg-gray-700 rounded-lg mb-3 overflow-hidden">
                    <img 
                      src={file.url} 
                      alt={file.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}

                {file.type === 'video' && (
                  <div className="aspect-video bg-gray-700 rounded-lg mb-3 flex items-center justify-center">
                    <Video className="text-gray-400" size={32} />
                  </div>
                )}

                <div>
                  <h4 className="font-medium text-text-light text-sm truncate" title={file.name}>
                    {file.name}
                  </h4>
                  <div className="flex items-center justify-between text-xs text-gray-400 mt-1">
                    <span>{file.size}</span>
                    <span>{file.uploadDate}</span>
                  </div>
                </div>

                <div className="mt-3 pt-3 border-t border-gray-700">
                  <Input
                    placeholder="Copy URL..."
                    value={file.url}
                    readOnly
                    className="bg-deep-dark border-gray-600 text-xs h-8"
                    onClick={(e) => {
                      e.currentTarget.select();
                      navigator.clipboard.writeText(file.url);
                      toast({
                        title: "URL Copied",
                        description: "File URL copied to clipboard",
                      });
                    }}
                  />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="bg-dark-surface">
          <CardContent className="p-12 text-center">
            <div className="w-24 h-24 bg-gray-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Upload className="text-gray-400" size={48} />
            </div>
            <h3 className="text-xl font-semibold text-text-light mb-2">No files uploaded yet</h3>
            <p className="text-gray-400 mb-6 max-w-md mx-auto">
              Start building your media library by uploading images, videos, audio files, and documents.
            </p>
            <Button onClick={() => setIsUploadOpen(true)} className="bg-light-blue hover:bg-accent-blue">
              <Upload className="mr-2" size={16} />
              Upload Your First File
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}