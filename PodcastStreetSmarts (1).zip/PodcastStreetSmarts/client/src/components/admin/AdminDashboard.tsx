import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Video, 
  Camera, 
  MessageCircle, 
  Users, 
  TrendingUp,
  Heart,
  Eye,
  Calendar,
  Plus,
  Edit,
  Settings,
  Upload,
  Trash2
} from "lucide-react";
import QuickActions from "@/components/admin/QuickActions";
import type { Video as VideoType, Photo, ForumPost } from "@shared/schema";
import { useState } from "react";

interface AdminDashboardProps {
  onTabSwitch?: (tab: string) => void;
}

export default function AdminDashboard({ onTabSwitch }: AdminDashboardProps) {
  const { data: videos, isLoading: videosLoading } = useQuery<VideoType[]>({
    queryKey: ["/api/videos"],
  });

  const { data: photos, isLoading: photosLoading } = useQuery<Photo[]>({
    queryKey: ["/api/photos"],
  });

  const { data: forumPosts, isLoading: forumLoading } = useQuery<ForumPost[]>({
    queryKey: ["/api/forum"],
  });

  if (videosLoading || photosLoading || forumLoading) {
    return (
      <div className="space-y-4 sm:space-y-6">
        <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="bg-dark-surface">
              <CardContent className="p-3 sm:p-6">
                <Skeleton className="h-8 w-8 sm:h-12 sm:w-12 rounded-full mb-2 sm:mb-4" />
                <Skeleton className="h-6 sm:h-8 w-16 sm:w-20 mb-1 sm:mb-2" />
                <Skeleton className="h-3 sm:h-4 w-12 sm:w-16" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const stats = [
    {
      title: "Total Videos",
      value: videos?.length || 0,
      icon: Video,
      color: "text-blue-400",
      bgColor: "bg-blue-500/20",
    },
    {
      title: "Total Photos",
      value: photos?.length || 0,
      icon: Camera,
      color: "text-green-400",
      bgColor: "bg-green-500/20",
    },
    {
      title: "Forum Posts",
      value: forumPosts?.length || 0,
      icon: MessageCircle,
      color: "text-purple-400",
      bgColor: "bg-purple-500/20",
    },
    {
      title: "Community",
      value: "Growing",
      icon: Users,
      color: "text-accent-blue",
      bgColor: "bg-accent-blue/20",
    },
  ];

  const recentVideos = videos?.slice(0, 3) || [];
  const recentPhotos = photos?.slice(0, 3) || [];
  const recentPosts = forumPosts?.slice(0, 5) || [];

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Mobile-Responsive Welcome Header for Malissa */}
      <Card className="bg-gradient-to-r from-light-blue/20 to-accent-blue/20 border-light-blue/30">
        <CardContent className="p-4 sm:p-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="text-center sm:text-left">
              <h3 className="text-xl sm:text-2xl font-bold text-text-light">Welcome Malissa! 👋</h3>
              <p className="text-accent-blue mt-1 text-sm sm:text-base">Complete control over your podcast website</p>
            </div>
            <div className="flex flex-col sm:flex-row gap-2 sm:space-x-4 sm:gap-0">
              <Button className="w-full sm:w-auto bg-light-blue hover:bg-accent-blue text-xs sm:text-sm">
                <Plus className="mr-2" size={16} />
                Create Content
              </Button>
              <Button variant="outline" className="w-full sm:w-auto border-light-blue text-light-blue hover:bg-light-blue hover:text-white text-xs sm:text-sm">
                <Settings className="mr-2" size={16} />
                Quick Settings
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Mobile-Responsive Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6">
        {stats.map((stat, index) => (
          <Card key={index} className="bg-dark-surface hover:bg-gray-800 transition-colors cursor-pointer group">
            <CardContent className="p-3 sm:p-6">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div className="flex flex-col sm:flex-row sm:items-center">
                  <div className={`w-8 h-8 sm:w-12 sm:h-12 ${stat.bgColor} rounded-full flex items-center justify-center group-hover:scale-110 transition-transform mb-2 sm:mb-0`}>
                    <stat.icon className={stat.color} size={16} sm:size={24} />
                  </div>
                  <div className="sm:ml-4 text-center sm:text-left">
                    <div className="text-lg sm:text-2xl font-bold text-text-light">{stat.value}</div>
                    <div className="text-xs sm:text-sm text-gray-400">{stat.title}</div>
                  </div>
                </div>
                <Button size="sm" variant="ghost" className="hidden sm:block opacity-0 group-hover:opacity-100 transition-opacity">
                  <Edit size={16} />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Videos */}
        <Card className="bg-dark-surface">
          <CardHeader>
            <CardTitle className="text-text-light flex items-center">
              <Video className="mr-2 text-blue-400" size={20} />
              Recent Videos
            </CardTitle>
          </CardHeader>
          <CardContent>
            {recentVideos.length > 0 ? (
              <div className="space-y-4">
                {recentVideos.map((video) => (
                  <div key={video.id} className="flex items-center space-x-4 p-3 hover:bg-deep-dark rounded-lg transition-colors">
                    <img 
                      src={video.thumbnail || "https://images.unsplash.com/photo-1516280440614-37939bbacd81?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=60"} 
                      alt={video.title} 
                      className="w-16 h-10 object-cover rounded"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-text-light truncate">{video.title}</h4>
                      <p className="text-sm text-gray-400 truncate">{video.description}</p>
                      <div className="flex items-center text-xs text-gray-500 mt-1">
                        <Calendar size={12} className="mr-1" />
                        {video.createdAt ? new Date(video.createdAt).toLocaleDateString() : 'Recently'}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-400 text-center py-8">No videos yet. Create your first video!</p>
            )}
          </CardContent>
        </Card>

        {/* Recent Photos */}
        <Card className="bg-dark-surface">
          <CardHeader>
            <CardTitle className="text-text-light flex items-center">
              <Camera className="mr-2 text-green-400" size={20} />
              Recent Photos
            </CardTitle>
          </CardHeader>
          <CardContent>
            {recentPhotos.length > 0 ? (
              <div className="grid grid-cols-3 gap-3">
                {recentPhotos.map((photo) => (
                  <div key={photo.id} className="group relative">
                    <img 
                      src={photo.imageUrl} 
                      alt={photo.title} 
                      className="w-full h-20 object-cover rounded-lg group-hover:opacity-75 transition-opacity"
                    />
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center">
                      <Eye className="text-white" size={20} />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-400 text-center py-8">No photos yet. Upload your first photo!</p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Forum Activity */}
      <Card className="bg-dark-surface">
        <CardHeader>
          <CardTitle className="text-text-light flex items-center">
            <MessageCircle className="mr-2 text-purple-400" size={20} />
            Recent Forum Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          {recentPosts.length > 0 ? (
            <div className="space-y-4">
              {recentPosts.map((post) => (
                <div key={post.id} className="flex items-start space-x-4 p-3 hover:bg-deep-dark rounded-lg transition-colors">
                  <div className="w-10 h-10 bg-gradient-to-r from-light-blue to-accent-blue rounded-full flex items-center justify-center text-white font-semibold text-sm">
                    {post.author.charAt(0).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-text-light">{post.title}</h4>
                    <p className="text-sm text-gray-400 mt-1">by {post.author}</p>
                    <div className="flex items-center text-xs text-gray-500 mt-2">
                      <Calendar size={12} className="mr-1" />
                      {post.createdAt ? new Date(post.createdAt).toLocaleDateString() : 'Recently'}
                      <span className="mx-2">•</span>
                      <MessageCircle size={12} className="mr-1" />
                      {post.replies || 0} replies
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-400 text-center py-8">No forum posts yet. Community activity will appear here.</p>
          )}
        </CardContent>
      </Card>

      {/* QuickActions Component with Working Buttons */}
      <QuickActions
        onVideoCreate={() => {
          console.log('Video Create clicked, switching to videos tab');
          if (onTabSwitch) {
            onTabSwitch('videos');
          } else {
            console.error('onTabSwitch not available');
          }
        }}
        onPhotoUpload={() => {
          if (onTabSwitch) {
            onTabSwitch('photos');
          }
        }}
        onForumModerate={() => {
          if (onTabSwitch) {
            onTabSwitch('forum');
          }
        }}
        onCommentManage={() => {
          if (onTabSwitch) {
            onTabSwitch('comments');
          }
        }}
        onSettingsOpen={() => {
          if (onTabSwitch) {
            onTabSwitch('settings');
          }
        }}
        onFilesManage={() => {
          if (onTabSwitch) {
            onTabSwitch('files');
          }
        }}
        onTextEdit={() => {
          if (onTabSwitch) {
            onTabSwitch('text');
          }
        }}
      />
    </div>
  );
}