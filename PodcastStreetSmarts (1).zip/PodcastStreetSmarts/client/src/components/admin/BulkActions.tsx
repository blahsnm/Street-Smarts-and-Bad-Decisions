import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Upload, 
  Download, 
  Trash2, 
  Copy,
  Edit,
  Archive,
  Share,
  Tag,
  CheckCircle
} from "lucide-react";

interface BulkActionsProps {
  selectedCount: number;
  onUploadMultiple: () => void;
  onDownloadSelected: () => void;
  onDeleteSelected: () => void;
  onCopySelected: () => void;
  onArchiveSelected: () => void;
}

export default function BulkActions({
  selectedCount,
  onUploadMultiple,
  onDownloadSelected,
  onDeleteSelected,
  onCopySelected,
  onArchiveSelected
}: BulkActionsProps) {
  const { toast } = useToast();

  const bulkActions = [
    {
      label: "Upload Multiple",
      icon: Upload,
      action: onUploadMultiple,
      color: "bg-light-blue hover:bg-accent-blue",
      description: "Upload multiple files at once"
    },
    {
      label: "Download All",
      icon: Download,
      action: onDownloadSelected,
      color: "bg-light-blue hover:bg-accent-blue",
      description: "Download selected files as ZIP",
      requiresSelection: true
    },
    {
      label: "Copy Files",
      icon: Copy,
      action: onCopySelected,
      color: "bg-light-blue hover:bg-accent-blue",
      description: "Duplicate selected files",
      requiresSelection: true
    },
    {
      label: "Archive",
      icon: Archive,
      action: onArchiveSelected,
      color: "bg-light-blue hover:bg-accent-blue",
      description: "Archive selected files",
      requiresSelection: true
    },
    {
      label: "Delete",
      icon: Trash2,
      action: onDeleteSelected,
      color: "bg-red-600 hover:bg-red-500",
      description: "Delete selected files permanently",
      requiresSelection: true
    }
  ];

  const handleAction = (action: () => void, requiresSelection: boolean, actionName: string) => {
    if (requiresSelection && selectedCount === 0) {
      toast({
        title: "No Selection",
        description: `Please select files before using ${actionName}`,
        variant: "destructive",
      });
      return;
    }
    action();
  };

  return (
    <Card className="bg-dark-surface">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="text-text-light">Bulk File Operations</CardTitle>
          {selectedCount > 0 && (
            <Badge className="bg-light-blue text-white">
              {selectedCount} files selected
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {bulkActions.map((item, index) => (
            <Button
              key={index}
              onClick={() => handleAction(item.action, item.requiresSelection || false, item.label)}
              className={`${item.color} text-white p-4 h-auto flex flex-col items-center space-y-2 transition-all duration-200 ${
                item.requiresSelection && selectedCount === 0 
                  ? 'opacity-50 cursor-not-allowed' 
                  : 'hover:scale-105'
              }`}
              disabled={item.requiresSelection && selectedCount === 0}
            >
              <item.icon size={24} />
              <div className="text-center">
                <div className="font-medium text-sm">{item.label}</div>
                <div className="text-xs opacity-90">{item.description}</div>
              </div>
            </Button>
          ))}
        </div>

        {/* Quick Stats */}
        <div className="mt-6 pt-6 border-t border-gray-700">
          <div className="grid grid-cols-3 md:grid-cols-6 gap-4 text-center">
            <div>
              <div className="text-xl font-bold text-text-light">24</div>
              <div className="text-xs text-gray-400">Total Files</div>
            </div>
            <div>
              <div className="text-xl font-bold text-green-400">12</div>
              <div className="text-xs text-gray-400">Images</div>
            </div>
            <div>
              <div className="text-xl font-bold text-blue-400">6</div>
              <div className="text-xs text-gray-400">Videos</div>
            </div>
            <div>
              <div className="text-xl font-bold text-purple-400">3</div>
              <div className="text-xs text-gray-400">Audio</div>
            </div>
            <div>
              <div className="text-xl font-bold text-yellow-400">3</div>
              <div className="text-xs text-gray-400">Documents</div>
            </div>
            <div>
              <div className="text-xl font-bold text-accent-blue">2.4 GB</div>
              <div className="text-xs text-gray-400">Total Size</div>
            </div>
          </div>
        </div>

        {/* File Operations Tips */}
        <div className="mt-6 p-4 bg-deep-dark rounded-lg border border-gray-700">
          <h4 className="font-medium text-text-light mb-3 flex items-center">
            <CheckCircle className="text-green-400 mr-2" size={16} />
            File Management Tips for Malissa
          </h4>
          <div className="grid md:grid-cols-2 gap-4 text-sm text-gray-400">
            <div>
              <h5 className="font-medium text-text-light mb-2">Organization</h5>
              <ul className="space-y-1">
                <li>• Use descriptive file names</li>
                <li>• Keep similar content together</li>
                <li>• Archive old files regularly</li>
              </ul>
            </div>
            <div>
              <h5 className="font-medium text-text-light mb-2">Best Practices</h5>
              <ul className="space-y-1">
                <li>• Optimize images before upload</li>
                <li>• Use consistent naming conventions</li>
                <li>• Back up important files</li>
              </ul>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}