import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { 
  MessageCircle, 
  Trash2, 
  Edit,
  Eye,
  EyeOff,
  Calendar,
  User,
  Flag,
  CheckCircle,
  XCircle,
  MoreHorizontal,
  Search,
  Filter
} from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface Comment {
  id: number;
  content: string;
  author: string;
  authorEmail?: string;
  postId?: number;
  postTitle?: string;
  status: "pending" | "approved" | "hidden" | "spam";
  createdAt: string;
  parentId?: number;
  replies?: Comment[];
}

export default function CommentManager() {
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedComment, setSelectedComment] = useState<Comment | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const { toast } = useToast();

  const { data: comments = [], isLoading } = useQuery({
    queryKey: ["/api/comments"],
    queryFn: async () => {
      // API call for real comments data
      const response = await apiRequest("GET", "/api/comments");
      return response.json();
    }
  });

  const updateCommentMutation = useMutation({
    mutationFn: async ({ id, status, content }: { id: number; status?: string; content?: string }) => {
      return await apiRequest("PUT", `/api/comments/${id}`, { status, content });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/comments"] });
      toast({
        title: "Success",
        description: "Comment updated successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update comment. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteCommentMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("DELETE", `/api/comments/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/comments"] });
      toast({
        title: "Success",
        description: "Comment deleted successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete comment. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleStatusChange = (commentId: number, newStatus: string) => {
    updateCommentMutation.mutate({ id: commentId, status: newStatus });
  };

  const handleDelete = (commentId: number, author: string) => {
    if (confirm(`Are you sure you want to delete the comment by ${author}?`)) {
      deleteCommentMutation.mutate(commentId);
    }
  };

  const handleEditSubmit = (content: string) => {
    if (selectedComment) {
      updateCommentMutation.mutate({ 
        id: selectedComment.id, 
        content 
      });
      setIsEditDialogOpen(false);
      setSelectedComment(null);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved": return "bg-green-500/20 text-green-400";
      case "pending": return "bg-yellow-500/20 text-yellow-400";
      case "hidden": return "bg-gray-500/20 text-gray-400";
      case "spam": return "bg-red-500/20 text-red-400";
      default: return "bg-gray-500/20 text-gray-400";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "approved": return <CheckCircle size={14} />;
      case "pending": return <Eye size={14} />;
      case "hidden": return <EyeOff size={14} />;
      case "spam": return <Flag size={14} />;
      default: return <MoreHorizontal size={14} />;
    }
  };

  const filteredComments = comments.filter(comment => {
    const matchesStatus = filterStatus === "all" || comment.status === filterStatus;
    const matchesSearch = searchTerm === "" || 
      comment.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
      comment.author.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const statusCounts = {
    all: comments.length,
    pending: comments.filter(c => c.status === "pending").length,
    approved: comments.filter(c => c.status === "approved").length,
    spam: comments.filter(c => c.status === "spam").length,
    hidden: comments.filter(c => c.status === "hidden").length,
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-10 w-32" />
        </div>
        <div className="space-y-4">
          {[...Array(5)].map((_, i) => (
            <Card key={i} className="bg-dark-surface">
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <Skeleton className="h-10 w-10 rounded-full" />
                  <div className="flex-1 space-y-2">
                    <Skeleton className="h-4 w-3/4" />
                    <Skeleton className="h-16 w-full" />
                    <div className="flex space-x-4">
                      <Skeleton className="h-4 w-20" />
                      <Skeleton className="h-4 w-16" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-text-light">Comment Management</h2>
          <p className="text-gray-400">Moderate and manage all user comments across your site</p>
        </div>
      </div>

      {/* Filters and Search */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
            <input
              type="text"
              placeholder="Search comments or authors..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-dark-surface border border-gray-700 rounded-lg text-text-light focus:border-light-blue focus:ring-1 focus:ring-light-blue"
            />
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <Filter className="text-gray-400" size={16} />
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="bg-dark-surface border-gray-700 w-48">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Comments ({statusCounts.all})</SelectItem>
              <SelectItem value="pending">Pending ({statusCounts.pending})</SelectItem>
              <SelectItem value="approved">Approved ({statusCounts.approved})</SelectItem>
              <SelectItem value="spam">Spam ({statusCounts.spam})</SelectItem>
              <SelectItem value="hidden">Hidden ({statusCounts.hidden})</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {Object.entries(statusCounts).map(([status, count]) => (
          <Card key={status} className="bg-dark-surface">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-text-light">{count}</div>
              <div className="text-sm text-gray-400 capitalize">{status}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Comments List */}
      {filteredComments.length > 0 ? (
        <div className="space-y-4">
          {filteredComments.map((comment) => (
            <Card key={comment.id} className="bg-dark-surface">
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 bg-gradient-to-r from-light-blue to-accent-blue rounded-full flex items-center justify-center text-white font-semibold text-sm flex-shrink-0">
                    {comment.author.charAt(0).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h4 className="font-semibold text-text-light">{comment.author}</h4>
                          <Badge className={getStatusColor(comment.status)}>
                            {getStatusIcon(comment.status)}
                            <span className="ml-1 capitalize">{comment.status}</span>
                          </Badge>
                          {comment.postTitle && (
                            <span className="text-xs text-gray-500">
                              on "{comment.postTitle}"
                            </span>
                          )}
                        </div>
                        <p className="text-gray-300 mb-3 leading-relaxed">{comment.content}</p>
                        <div className="flex items-center space-x-4 text-xs text-gray-500">
                          <div className="flex items-center">
                            <Calendar size={12} className="mr-1" />
                            {new Date(comment.createdAt).toLocaleString()}
                          </div>
                          {comment.authorEmail && (
                            <div className="flex items-center">
                              <User size={12} className="mr-1" />
                              {comment.authorEmail}
                            </div>
                          )}
                          {comment.replies && comment.replies.length > 0 && (
                            <div className="flex items-center">
                              <MessageCircle size={12} className="mr-1" />
                              {comment.replies.length} {comment.replies.length === 1 ? 'reply' : 'replies'}
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center space-x-2 ml-4">
                        {/* Status Change Buttons */}
                        {comment.status !== "approved" && (
                          <Button
                            size="sm"
                            onClick={() => handleStatusChange(comment.id, "approved")}
                            className="bg-light-blue hover:bg-accent-blue text-white"
                          >
                            <CheckCircle size={14} className="mr-1" />
                            Approve
                          </Button>
                        )}
                        {comment.status !== "hidden" && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleStatusChange(comment.id, "hidden")}
                            className="border-gray-600 text-gray-400 hover:bg-gray-600 hover:text-white"
                          >
                            <EyeOff size={14} className="mr-1" />
                            Hide
                          </Button>
                        )}
                        {comment.status !== "spam" && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleStatusChange(comment.id, "spam")}
                            className="border-light-blue text-light-blue hover:bg-light-blue hover:text-white"
                          >
                            <Flag size={14} className="mr-1" />
                            Spam
                          </Button>
                        )}
                        
                        {/* Edit Button */}
                        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
                          <DialogTrigger asChild>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setSelectedComment(comment)}
                              className="border-light-blue text-light-blue hover:bg-light-blue hover:text-white"
                            >
                              <Edit size={14} />
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="bg-dark-surface text-text-light">
                            <DialogHeader>
                              <DialogTitle>Edit Comment</DialogTitle>
                            </DialogHeader>
                            <form onSubmit={(e) => {
                              e.preventDefault();
                              const formData = new FormData(e.currentTarget);
                              handleEditSubmit(formData.get("content") as string);
                            }}>
                              <div className="space-y-4">
                                <div>
                                  <label className="text-sm font-medium">Author: {selectedComment?.author}</label>
                                </div>
                                <Textarea
                                  name="content"
                                  defaultValue={selectedComment?.content}
                                  className="bg-deep-dark border-gray-700"
                                  rows={4}
                                />
                                <div className="flex justify-end space-x-2">
                                  <Button 
                                    type="button" 
                                    variant="outline"
                                    onClick={() => setIsEditDialogOpen(false)}
                                  >
                                    Cancel
                                  </Button>
                                  <Button type="submit" className="bg-light-blue hover:bg-accent-blue">
                                    Save Changes
                                  </Button>
                                </div>
                              </div>
                            </form>
                          </DialogContent>
                        </Dialog>

                        {/* Delete Button */}
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDelete(comment.id, comment.author)}
                          className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white"
                        >
                          <Trash2 size={14} />
                        </Button>
                      </div>
                    </div>

                    {/* Replies */}
                    {comment.replies && comment.replies.length > 0 && (
                      <div className="ml-6 mt-4 space-y-3">
                        {comment.replies.map((reply) => (
                          <div key={reply.id} className="bg-deep-dark rounded-lg p-4 border-l-2 border-light-blue">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-2">
                                  <div className="w-6 h-6 bg-accent-blue rounded-full flex items-center justify-center text-white text-xs">
                                    {reply.author.charAt(0).toUpperCase()}
                                  </div>
                                  <span className="font-medium text-sm text-text-light">{reply.author}</span>
                                  <Badge className={getStatusColor(reply.status)} variant="outline">
                                    {reply.status}
                                  </Badge>
                                </div>
                                <p className="text-sm text-gray-300 mb-2">{reply.content}</p>
                                <div className="text-xs text-gray-500">
                                  {new Date(reply.createdAt).toLocaleString()}
                                </div>
                              </div>
                              <div className="flex items-center space-x-1 ml-4">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleStatusChange(reply.id, reply.status === "approved" ? "hidden" : "approved")}
                                  className="h-7 w-7 p-0"
                                >
                                  {reply.status === "approved" ? <EyeOff size={12} /> : <CheckCircle size={12} />}
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleDelete(reply.id, reply.author)}
                                  className="h-7 w-7 p-0 border-red-600 text-red-400 hover:bg-red-600 hover:text-white"
                                >
                                  <Trash2 size={12} />
                                </Button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="bg-dark-surface">
          <CardContent className="p-12 text-center">
            <div className="w-24 h-24 bg-purple-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <MessageCircle className="text-purple-400" size={48} />
            </div>
            <h3 className="text-xl font-semibold text-text-light mb-2">No comments found</h3>
            <p className="text-gray-400">
              {searchTerm || filterStatus !== "all" 
                ? "Try adjusting your search or filter criteria."
                : "Comments from your audience will appear here once they start engaging with your content."
              }
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}