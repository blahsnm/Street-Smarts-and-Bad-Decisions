import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { 
  Camera, 
  Plus, 
  Edit, 
  Trash2, 
  Calendar,
  Eye
} from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Photo, InsertPhoto } from "@shared/schema";

export default function AdminPhotos() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingPhoto, setEditingPhoto] = useState<Photo | null>(null);
  const { toast } = useToast();

  const { data: photos, isLoading } = useQuery<Photo[]>({
    queryKey: ["/api/photos"],
  });

  const createMutation = useMutation({
    mutationFn: async (photoData: InsertPhoto) => {
      return await apiRequest("POST", "/api/photos", photoData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/photos"] });
      setIsDialogOpen(false);
      setEditingPhoto(null);
      toast({
        title: "Success",
        description: "Photo added successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add photo. Please try again.",
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: InsertPhoto }) => {
      return await apiRequest("PUT", `/api/photos/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/photos"] });
      setIsDialogOpen(false);
      setEditingPhoto(null);
      toast({
        title: "Success",
        description: "Photo updated successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update photo. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("DELETE", `/api/photos/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/photos"] });
      toast({
        title: "Success",
        description: "Photo deleted successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete photo. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const photoData: InsertPhoto = {
      title: formData.get("title") as string,
      description: formData.get("description") as string || null,
      imageUrl: formData.get("imageUrl") as string,
      category: formData.get("category") as string || null,
    };

    if (editingPhoto) {
      updateMutation.mutate({ id: editingPhoto.id, data: photoData });
    } else {
      createMutation.mutate(photoData);
    }
  };

  const handleEdit = (photo: Photo) => {
    setEditingPhoto(photo);
    setIsDialogOpen(true);
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this photo?")) {
      deleteMutation.mutate(id);
    }
  };

  const openNewPhotoDialog = () => {
    setEditingPhoto(null);
    setIsDialogOpen(true);
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-10 w-32" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <Skeleton key={i} className="aspect-square w-full rounded-xl" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-text-light">Photo Management</h2>
          <p className="text-gray-400">Manage your photography portfolio and gallery</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={openNewPhotoDialog} className="bg-light-blue hover:bg-accent-blue">
              <Plus className="mr-2" size={16} />
              Add Photo
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-dark-surface text-text-light">
            <DialogHeader>
              <DialogTitle>
                {editingPhoto ? "Edit Photo" : "Add New Photo"}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="title">Title *</Label>
                <Input
                  id="title"
                  name="title"
                  defaultValue={editingPhoto?.title || ""}
                  required
                  className="bg-deep-dark border-gray-700"
                />
              </div>
              
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  name="description"
                  defaultValue={editingPhoto?.description || ""}
                  className="bg-deep-dark border-gray-700"
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="imageUrl">Image URL *</Label>
                <Input
                  id="imageUrl"
                  name="imageUrl"
                  type="url"
                  defaultValue={editingPhoto?.imageUrl || ""}
                  required
                  className="bg-deep-dark border-gray-700"
                />
              </div>
                
              <div>
                <Label htmlFor="category">Category</Label>
                <Select name="category" defaultValue={editingPhoto?.category || ""}>
                  <SelectTrigger className="bg-deep-dark border-gray-700">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="street">Street Photography</SelectItem>
                    <SelectItem value="urban">Urban Landscapes</SelectItem>
                    <SelectItem value="people">People & Portraits</SelectItem>
                    <SelectItem value="abstract">Abstract</SelectItem>
                    <SelectItem value="documentary">Documentary</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex justify-end space-x-2">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsDialogOpen(false)}
                  className="border-gray-600"
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  className="bg-light-blue hover:bg-accent-blue"
                  disabled={createMutation.isPending || updateMutation.isPending}
                >
                  {editingPhoto ? "Update" : "Add"} Photo
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Photos Grid */}
      {photos && photos.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {photos.map((photo) => (
            <Card key={photo.id} className="bg-dark-surface overflow-hidden group">
              <div className="aspect-square relative">
                <img 
                  src={photo.imageUrl} 
                  alt={photo.title} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute top-2 right-2 flex space-x-1">
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-8 w-8 p-0 bg-black/50 border-white/20"
                      onClick={() => handleEdit(photo)}
                    >
                      <Edit size={14} />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-8 w-8 p-0 bg-black/50 border-white/20 hover:bg-red-500"
                      onClick={() => handleDelete(photo.id)}
                    >
                      <Trash2 size={14} />
                    </Button>
                  </div>
                  <div className="absolute bottom-4 left-4 right-4">
                    <h4 className="text-white font-semibold mb-1">{photo.title}</h4>
                    {photo.description && (
                      <p className="text-gray-200 text-sm line-clamp-2">{photo.description}</p>
                    )}
                  </div>
                </div>
                {photo.category && (
                  <span className="absolute top-2 left-2 bg-black/70 text-white px-2 py-1 rounded text-xs">
                    {photo.category}
                  </span>
                )}
              </div>
              <CardContent className="p-4">
                <h3 className="font-semibold text-text-light mb-1">{photo.title}</h3>
                <div className="flex items-center justify-between text-xs text-gray-500">
                  <div className="flex items-center">
                    <Calendar size={12} className="mr-1" />
                    {photo.createdAt ? new Date(photo.createdAt).toLocaleDateString() : 'Recently'}
                  </div>
                  <div className="flex items-center">
                    <Eye size={12} className="mr-1" />
                    View
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="bg-dark-surface">
          <CardContent className="p-12 text-center">
            <div className="w-24 h-24 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Camera className="text-green-400" size={48} />
            </div>
            <h3 className="text-xl font-semibold text-text-light mb-2">No photos yet</h3>
            <p className="text-gray-400 mb-6 max-w-md mx-auto">
              Start building your photography portfolio by adding your first image to the gallery.
            </p>
            <Button onClick={openNewPhotoDialog} className="bg-light-blue hover:bg-accent-blue">
              <Plus className="mr-2" size={16} />
              Add Your First Photo
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}