import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Type, 
  Save, 
  RotateCcw, 
  Eye,
  Menu,
  Home,
  Video,
  Camera,
  MessageCircle,
  Info,
  Heart,
  Edit
} from "lucide-react";

interface TextEditorProps {
  onSave: (textContent: any) => void;
}

export default function TextEditor({ onSave }: TextEditorProps) {
  const { toast } = useToast();
  
  const [textContent, setTextContent] = useState({
    navigation: {
      home: "Home",
      videos: "Episodes", 
      photography: "Gallery",
      streetSmarts: "Street Smarts",
      badDecisions: "Bad Decisions",
      forum: "Community",
      about: "About",
      donate: "Support Us"
    },
    heroSection: {
      title: "Street Smarts & Bad Decisions",
      subtitle: "Where wisdom meets chaos in the digital age",
      buttonText: "Listen Now"
    },
    pages: {
      aboutTitle: "About Our Podcast",
      aboutContent: "Welcome to Street Smarts & Bad Decisions, where we explore the fine line between wisdom and questionable choices in our daily lives.",
      videosTitle: "Latest Episodes",
      videosSubtitle: "Catch up on our recent discussions",
      photographyTitle: "Street Photography Gallery",
      photographySubtitle: "Capturing urban life through our lens",
      forumTitle: "Community Discussions",
      forumSubtitle: "Join the conversation with fellow listeners",
      donateTitle: "Support Our Show",
      donateSubtitle: "Help us keep creating great content"
    },
    buttons: {
      watchNow: "Watch Now",
      listenNow: "Listen Now",
      viewGallery: "View Gallery",
      joinDiscussion: "Join Discussion",
      learnMore: "Learn More",
      getStarted: "Get Started",
      subscribe: "Subscribe",
      followUs: "Follow Us"
    },
    messages: {
      welcome: "Welcome to our community!",
      thankYou: "Thank you for your support!",
      contactUs: "Get in touch with us",
      newsletter: "Subscribe to our newsletter",
      loading: "Loading...",
      noContent: "No content available yet",
      comingSoon: "Coming soon..."
    }
  });

  const handleSave = () => {
    onSave(textContent);
    toast({
      title: "Success",
      description: "All text content updated successfully!",
    });
  };

  const resetToDefaults = () => {
    // Reset logic would go here
    toast({
      title: "Reset",
      description: "Text content reset to defaults",
    });
  };

  const previewText = (category: string, key: string) => {
    const categoryContent = textContent[category as keyof typeof textContent];
    if (categoryContent && typeof categoryContent === 'object') {
      return (categoryContent as any)[key] || '';
    }
    return '';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-text-light">Text & Content Editor</h2>
          <p className="text-gray-400">Customize all text, phrases, and menu titles throughout your website, Malissa</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button 
            onClick={resetToDefaults}
            variant="outline" 
            className="border-gray-600"
          >
            <RotateCcw className="mr-2" size={16} />
            Reset to Defaults
          </Button>
          <Button 
            onClick={handleSave}
            className="bg-light-blue hover:bg-accent-blue"
          >
            <Save className="mr-2" size={16} />
            Save All Changes
          </Button>
        </div>
      </div>

      <Tabs defaultValue="navigation" className="w-full">
        <TabsList className="grid w-full grid-cols-5 bg-dark-surface">
          <TabsTrigger value="navigation">
            <Menu className="mr-2" size={16} />
            Navigation
          </TabsTrigger>
          <TabsTrigger value="hero">
            <Home className="mr-2" size={16} />
            Hero Section
          </TabsTrigger>
          <TabsTrigger value="pages">
            <Type className="mr-2" size={16} />
            Page Content
          </TabsTrigger>
          <TabsTrigger value="buttons">
            <Edit className="mr-2" size={16} />
            Buttons
          </TabsTrigger>
          <TabsTrigger value="messages">
            <MessageCircle className="mr-2" size={16} />
            Messages
          </TabsTrigger>
        </TabsList>

        {/* Navigation Menu Text */}
        <TabsContent value="navigation" className="space-y-6">
          <Card className="bg-dark-surface">
            <CardHeader>
              <CardTitle className="text-text-light">Navigation Menu Labels</CardTitle>
              <p className="text-sm text-gray-400">Customize how menu items appear in your navigation</p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {Object.entries(textContent.navigation).map(([key, value]) => (
                  <div key={key}>
                    <Label className="text-base font-medium capitalize">
                      {key.replace(/([A-Z])/g, ' $1').trim()} Menu Item
                    </Label>
                    <Input
                      value={value}
                      onChange={(e) => setTextContent({
                        ...textContent,
                        navigation: { ...textContent.navigation, [key]: e.target.value }
                      })}
                      className="bg-deep-dark border-gray-700 mt-2"
                    />
                    <div className="flex items-center mt-1 text-xs text-gray-500">
                      <Eye size={12} className="mr-1" />
                      Current: "{value}"
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Hero Section Text */}
        <TabsContent value="hero" className="space-y-6">
          <Card className="bg-dark-surface">
            <CardHeader>
              <CardTitle className="text-text-light">Hero Section Content</CardTitle>
              <p className="text-sm text-gray-400">Main homepage banner text and call-to-action</p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label className="text-base font-medium">Main Title</Label>
                <Input
                  value={textContent.heroSection.title}
                  onChange={(e) => setTextContent({
                    ...textContent,
                    heroSection: { ...textContent.heroSection, title: e.target.value }
                  })}
                  className="bg-deep-dark border-gray-700 mt-2"
                  placeholder="Your podcast name"
                />
              </div>
              
              <div>
                <Label className="text-base font-medium">Subtitle/Tagline</Label>
                <Textarea
                  value={textContent.heroSection.subtitle}
                  onChange={(e) => setTextContent({
                    ...textContent,
                    heroSection: { ...textContent.heroSection, subtitle: e.target.value }
                  })}
                  className="bg-deep-dark border-gray-700 mt-2"
                  rows={2}
                  placeholder="Brief description of your show"
                />
              </div>

              <div>
                <Label className="text-base font-medium">Call-to-Action Button</Label>
                <Input
                  value={textContent.heroSection.buttonText}
                  onChange={(e) => setTextContent({
                    ...textContent,
                    heroSection: { ...textContent.heroSection, buttonText: e.target.value }
                  })}
                  className="bg-deep-dark border-gray-700 mt-2"
                  placeholder="Button text"
                />
              </div>

              {/* Preview */}
              <div className="mt-6 p-6 bg-deep-dark rounded-lg border border-gray-700">
                <Label className="text-base font-medium mb-4 block">Preview</Label>
                <div className="text-center">
                  <h1 className="text-3xl font-bold text-text-light mb-2">
                    {textContent.heroSection.title}
                  </h1>
                  <p className="text-gray-300 mb-4">
                    {textContent.heroSection.subtitle}
                  </p>
                  <Button className="bg-light-blue hover:bg-accent-blue">
                    {textContent.heroSection.buttonText}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Page Content */}
        <TabsContent value="pages" className="space-y-6">
          <Card className="bg-dark-surface">
            <CardHeader>
              <CardTitle className="text-text-light">Page Titles & Content</CardTitle>
              <p className="text-sm text-gray-400">Customize headings and descriptions for each page</p>
            </CardHeader>
            <CardContent className="space-y-6">
              {Object.entries(textContent.pages).map(([key, value]) => (
                <div key={key}>
                  <Label className="text-base font-medium">
                    {key.replace(/([A-Z])/g, ' $1').replace(/Title|Content|Subtitle/g, '').trim()} - {
                      key.includes('Title') ? 'Page Title' : 
                      key.includes('Subtitle') ? 'Subtitle' : 'Content'
                    }
                  </Label>
                  {key.includes('Content') ? (
                    <Textarea
                      value={value}
                      onChange={(e) => setTextContent({
                        ...textContent,
                        pages: { ...textContent.pages, [key]: e.target.value }
                      })}
                      className="bg-deep-dark border-gray-700 mt-2"
                      rows={3}
                    />
                  ) : (
                    <Input
                      value={value}
                      onChange={(e) => setTextContent({
                        ...textContent,
                        pages: { ...textContent.pages, [key]: e.target.value }
                      })}
                      className="bg-deep-dark border-gray-700 mt-2"
                    />
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Button Text */}
        <TabsContent value="buttons" className="space-y-6">
          <Card className="bg-dark-surface">
            <CardHeader>
              <CardTitle className="text-text-light">Button Labels</CardTitle>
              <p className="text-sm text-gray-400">Customize all button text throughout the site</p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {Object.entries(textContent.buttons).map(([key, value]) => (
                  <div key={key}>
                    <Label className="text-base font-medium">
                      {key.replace(/([A-Z])/g, ' $1').trim()} Button
                    </Label>
                    <Input
                      value={value}
                      onChange={(e) => setTextContent({
                        ...textContent,
                        buttons: { ...textContent.buttons, [key]: e.target.value }
                      })}
                      className="bg-deep-dark border-gray-700 mt-2"
                    />
                    <div className="mt-2">
                      <Button size="sm" className="bg-light-blue hover:bg-accent-blue text-xs">
                        {value}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Messages & Notifications */}
        <TabsContent value="messages" className="space-y-6">
          <Card className="bg-dark-surface">
            <CardHeader>
              <CardTitle className="text-text-light">Messages & Status Text</CardTitle>
              <p className="text-sm text-gray-400">Customize system messages and user notifications</p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {Object.entries(textContent.messages).map(([key, value]) => (
                  <div key={key}>
                    <Label className="text-base font-medium">
                      {key.replace(/([A-Z])/g, ' $1').trim()} Message
                    </Label>
                    <Input
                      value={value}
                      onChange={(e) => setTextContent({
                        ...textContent,
                        messages: { ...textContent.messages, [key]: e.target.value }
                      })}
                      className="bg-deep-dark border-gray-700 mt-2"
                    />
                    <Badge variant="outline" className="mt-1 text-xs">
                      Used in: {key.includes('welcome') ? 'Homepage' : 
                               key.includes('thank') ? 'Donation page' :
                               key.includes('loading') ? 'All pages' : 'Various locations'}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}