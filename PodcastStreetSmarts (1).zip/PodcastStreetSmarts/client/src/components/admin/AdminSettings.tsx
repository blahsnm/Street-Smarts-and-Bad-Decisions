import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { 
  Settings, 
  Save, 
  Palette, 
  Globe, 
  CreditCard,
  Link,
  Upload,
  Eye,
  Type,
  Image,
  Layout,
  Menu,
  Home,
  Camera,
  Video,
  MessageCircle,
  Heart,
  Info,
  Code,
  Smartphone
} from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { SiteSettings, InsertSiteSettings } from "@shared/schema";

export default function AdminSettings() {
  const { toast } = useToast();

  const { data: settings, isLoading } = useQuery<SiteSettings>({
    queryKey: ["/api/settings"],
  });

  const updateMutation = useMutation({
    mutationFn: async (settingsData: InsertSiteSettings) => {
      return await apiRequest("PUT", "/api/settings", settingsData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({
        title: "Success",
        description: "Settings updated successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update settings. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const socialLinks = {
      spotify: formData.get("spotify") as string || undefined,
      youtube: formData.get("youtube") as string || undefined,
      instagram: formData.get("instagram") as string || undefined,
      twitter: formData.get("twitter") as string || undefined,
    };

    // Remove undefined values
    Object.keys(socialLinks).forEach(key => {
      if (!socialLinks[key as keyof typeof socialLinks]) {
        delete socialLinks[key as keyof typeof socialLinks];
      }
    });

    const settingsData: InsertSiteSettings = {
      logoUrl: formData.get("logoUrl") as string || null,
      siteName: formData.get("siteName") as string || null,
      siteDescription: formData.get("siteDescription") as string || null,
      primaryColor: formData.get("primaryColor") as string || null,
      secondaryColor: formData.get("secondaryColor") as string || null,
      socialLinks: Object.keys(socialLinks).length > 0 ? socialLinks : null,
      stripePublicKey: formData.get("stripePublicKey") as string || null,
      donationGoal: parseInt(formData.get("donationGoal") as string) || null,
    };

    updateMutation.mutate(settingsData);
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-48" />
        <div className="grid gap-6">
          {[...Array(3)].map((_, i) => (
            <Card key={i} className="bg-dark-surface">
              <CardHeader>
                <Skeleton className="h-6 w-32" />
              </CardHeader>
              <CardContent className="space-y-4">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-20 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-text-light">Website Editor</h2>
          <p className="text-gray-400">Customize every aspect of your website with our user-friendly editor</p>
        </div>
        <Button 
          form="settings-form"
          type="submit"
          className="bg-light-blue hover:bg-accent-blue"
          disabled={updateMutation.isPending}
        >
          <Save className="mr-2" size={16} />
          Save All Changes
        </Button>
      </div>

      <Tabs defaultValue="branding" className="w-full">
        <TabsList className="grid w-full grid-cols-6 bg-dark-surface">
          <TabsTrigger value="branding" className="flex items-center space-x-2">
            <Globe size={16} />
            <span className="hidden sm:inline">Branding</span>
          </TabsTrigger>
          <TabsTrigger value="pages" className="flex items-center space-x-2">
            <Layout size={16} />
            <span className="hidden sm:inline">Pages</span>
          </TabsTrigger>
          <TabsTrigger value="navigation" className="flex items-center space-x-2">
            <Menu size={16} />
            <span className="hidden sm:inline">Navigation</span>
          </TabsTrigger>
          <TabsTrigger value="appearance" className="flex items-center space-x-2">
            <Palette size={16} />
            <span className="hidden sm:inline">Appearance</span>
          </TabsTrigger>
          <TabsTrigger value="social" className="flex items-center space-x-2">
            <Link size={16} />
            <span className="hidden sm:inline">Social</span>
          </TabsTrigger>
          <TabsTrigger value="payments" className="flex items-center space-x-2">
            <CreditCard size={16} />
            <span className="hidden sm:inline">Payments</span>
          </TabsTrigger>
        </TabsList>

        <form id="settings-form" onSubmit={handleSubmit} className="mt-6">
          {/* Branding Tab */}
          <TabsContent value="branding" className="space-y-6">
            <Card className="bg-dark-surface">
              <CardHeader>
                <CardTitle className="text-text-light flex items-center">
                  <Type className="mr-2 text-blue-400" size={20} />
                  Brand Identity
                </CardTitle>
                <p className="text-sm text-gray-400">
                  Set your podcast name, tagline, and brand identity
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="siteName" className="text-base font-medium">Podcast Name *</Label>
                    <Input
                      id="siteName"
                      name="siteName"
                      defaultValue={settings?.siteName || "Street Smarts & Bad Decisions"}
                      className="bg-deep-dark border-gray-700 mt-2"
                      placeholder="Your Podcast Name"
                    />
                    <p className="text-xs text-gray-500 mt-1">This appears in the header and browser title</p>
                  </div>
                  <div>
                    <Label htmlFor="logoUrl" className="text-base font-medium">Logo URL</Label>
                    <Input
                      id="logoUrl"
                      name="logoUrl"
                      type="url"
                      defaultValue={settings?.logoUrl || ""}
                      placeholder="https://example.com/logo.png"
                      className="bg-deep-dark border-gray-700 mt-2"
                    />
                    <p className="text-xs text-gray-500 mt-1">Square logos work best (recommended: 200x200px)</p>
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="siteDescription" className="text-base font-medium">Tagline / Description</Label>
                  <Textarea
                    id="siteDescription"
                    name="siteDescription"
                    defaultValue={settings?.siteDescription || "Where wisdom meets chaos in the digital age"}
                    className="bg-deep-dark border-gray-700 mt-2"
                    rows={3}
                    placeholder="Describe your podcast in a few words..."
                  />
                  <p className="text-xs text-gray-500 mt-1">This appears below your podcast name and in search results</p>
                </div>

                <Separator className="bg-gray-700" />

                <div>
                  <Label className="text-base font-medium mb-4 block">Brand Preview</Label>
                  <div className="bg-deep-dark rounded-lg p-6 border border-gray-700">
                    <div className="flex items-center space-x-4">
                      {settings?.logoUrl && (
                        <img 
                          src={settings.logoUrl} 
                          alt="Logo" 
                          className="w-16 h-16 rounded-lg object-cover border-2 border-light-blue"
                        />
                      )}
                      <div>
                        <h3 className="text-xl font-bold text-text-light">
                          {settings?.siteName || "Street Smarts & Bad Decisions"}
                        </h3>
                        <p className="text-gray-400">
                          {settings?.siteDescription || "Where wisdom meets chaos in the digital age"}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Pages Tab */}
          <TabsContent value="pages" className="space-y-6">
            <Card className="bg-dark-surface">
              <CardHeader>
                <CardTitle className="text-text-light flex items-center">
                  <Layout className="mr-2 text-green-400" size={20} />
                  Page Content & Structure
                </CardTitle>
                <p className="text-sm text-gray-400">
                  Customize the content and layout of your website pages
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label className="text-base font-medium">Home Page Hero Section</Label>
                    <Textarea
                      name="heroText"
                      defaultValue="Welcome to Street Smarts & Bad Decisions"
                      className="bg-deep-dark border-gray-700 mt-2"
                      rows={2}
                      placeholder="Main headline for your home page"
                    />
                  </div>
                  <div>
                    <Label className="text-base font-medium">Hero Subtitle</Label>
                    <Textarea
                      name="heroSubtitle"
                      defaultValue="Where wisdom meets chaos in the digital age"
                      className="bg-deep-dark border-gray-700 mt-2"
                      rows={2}
                      placeholder="Supporting text under main headline"
                    />
                  </div>
                </div>

                <div>
                  <Label className="text-base font-medium">About Page Content</Label>
                  <Textarea
                    name="aboutContent"
                    defaultValue="Learn more about our podcast and mission..."
                    className="bg-deep-dark border-gray-700 mt-2"
                    rows={4}
                    placeholder="Tell your story and mission"
                  />
                  <p className="text-xs text-gray-500 mt-1">This content appears on your About page</p>
                </div>

                <Separator className="bg-gray-700" />

                <div>
                  <Label className="text-base font-medium mb-4 block">Page Visibility</Label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {[
                      { name: "Videos", icon: Video, enabled: true },
                      { name: "Photography", icon: Camera, enabled: true },
                      { name: "Street Smarts", icon: Home, enabled: true },
                      { name: "Bad Decisions", icon: MessageCircle, enabled: true },
                      { name: "Forum", icon: MessageCircle, enabled: true },
                      { name: "About", icon: Info, enabled: true },
                      { name: "Donate", icon: Heart, enabled: true },
                    ].map((page) => (
                      <div key={page.name} className="flex items-center space-x-3 p-3 bg-deep-dark rounded-lg">
                        <page.icon size={16} className="text-accent-blue" />
                        <span className="text-sm text-text-light flex-1">{page.name}</span>
                        <Switch defaultChecked={page.enabled} />
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Navigation Tab */}
          <TabsContent value="navigation" className="space-y-6">
            <Card className="bg-dark-surface">
              <CardHeader>
                <CardTitle className="text-text-light flex items-center">
                  <Menu className="mr-2 text-purple-400" size={20} />
                  Navigation & Menu
                </CardTitle>
                <p className="text-sm text-gray-400">
                  Customize your website navigation and menu structure
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label className="text-base font-medium mb-4 block">Menu Order & Labels</Label>
                  <div className="space-y-3">
                    {[
                      { current: "Home", label: "Home", url: "/" },
                      { current: "Videos", label: "Episodes", url: "/videos" },
                      { current: "Photography", label: "Gallery", url: "/photography" },
                      { current: "Street Smarts", label: "Street Smarts", url: "/street-smarts" },
                      { current: "Bad Decisions", label: "Bad Decisions", url: "/bad-decisions" },
                      { current: "Forum", label: "Community", url: "/forum" },
                      { current: "About", label: "About", url: "/about" },
                    ].map((item, index) => (
                      <div key={item.current} className="grid grid-cols-3 gap-4 p-3 bg-deep-dark rounded-lg">
                        <div>
                          <Label className="text-xs text-gray-400">Current</Label>
                          <p className="text-sm text-text-light font-medium">{item.current}</p>
                        </div>
                        <div>
                          <Label className="text-xs text-gray-400">Display As</Label>
                          <Input
                            defaultValue={item.label}
                            className="bg-gray-800 border-gray-600 text-sm h-8"
                            name={`nav_${item.current.toLowerCase()}_label`}
                          />
                        </div>
                        <div className="flex items-center justify-between">
                          <Switch defaultChecked={true} />
                          <span className="text-xs text-gray-500">#{index + 1}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Appearance Tab */}
          <TabsContent value="appearance" className="space-y-6">
            <Card className="bg-dark-surface">
              <CardHeader>
                <CardTitle className="text-text-light flex items-center">
                  <Palette className="mr-2 text-orange-400" size={20} />
                  Colors & Visual Design
                </CardTitle>
                <p className="text-sm text-gray-400">
                  Customize colors, fonts, and visual elements
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label className="text-base font-medium">Primary Brand Color</Label>
                    <div className="flex space-x-3 mt-2">
                      <Input
                        id="primaryColor"
                        name="primaryColor"
                        type="color"
                        defaultValue={settings?.primaryColor || "#3B82F6"}
                        className="bg-deep-dark border-gray-700 w-16 h-12"
                      />
                      <Input
                        defaultValue={settings?.primaryColor || "#3B82F6"}
                        className="bg-deep-dark border-gray-700 flex-1"
                        placeholder="#3B82F6"
                      />
                    </div>
                    <p className="text-xs text-gray-500 mt-1">Used for buttons and highlights</p>
                  </div>
                  <div>
                    <Label className="text-base font-medium">Secondary Color</Label>
                    <div className="flex space-x-3 mt-2">
                      <Input
                        id="secondaryColor"
                        name="secondaryColor"
                        type="color"
                        defaultValue={settings?.secondaryColor || "#60A5FA"}
                        className="bg-deep-dark border-gray-700 w-16 h-12"
                      />
                      <Input
                        defaultValue={settings?.secondaryColor || "#60A5FA"}
                        className="bg-deep-dark border-gray-700 flex-1"
                        placeholder="#60A5FA"
                      />
                    </div>
                    <p className="text-xs text-gray-500 mt-1">Used for accents and hover states</p>
                  </div>
                </div>

                <Separator className="bg-gray-700" />

                <div>
                  <Label className="text-base font-medium mb-4 block">Color Preview</Label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center">
                      <div 
                        className="w-full h-16 rounded-lg mb-2"
                        style={{ backgroundColor: settings?.primaryColor || "#3B82F6" }}
                      />
                      <p className="text-xs text-gray-400">Primary</p>
                    </div>
                    <div className="text-center">
                      <div 
                        className="w-full h-16 rounded-lg mb-2"
                        style={{ backgroundColor: settings?.secondaryColor || "#60A5FA" }}
                      />
                      <p className="text-xs text-gray-400">Secondary</p>
                    </div>
                    <div className="text-center">
                      <div className="w-full h-16 bg-gray-800 rounded-lg mb-2" />
                      <p className="text-xs text-gray-400">Background</p>
                    </div>
                    <div className="text-center">
                      <div className="w-full h-16 bg-text-light rounded-lg mb-2" />
                      <p className="text-xs text-gray-400">Text</p>
                    </div>
                  </div>
                </div>

                <div>
                  <Label className="text-base font-medium">Mobile Responsiveness</Label>
                  <div className="flex items-center justify-between p-4 bg-deep-dark rounded-lg mt-2">
                    <div className="flex items-center space-x-3">
                      <Smartphone size={20} className="text-accent-blue" />
                      <div>
                        <p className="text-sm font-medium text-text-light">Mobile-Optimized Design</p>
                        <p className="text-xs text-gray-400">Automatically adapts to all screen sizes</p>
                      </div>
                    </div>
                    <Switch defaultChecked={true} disabled />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Social Media Tab */}
          <TabsContent value="social" className="space-y-6">
            <Card className="bg-dark-surface">
              <CardHeader>
                <CardTitle className="text-text-light flex items-center">
                  <Link className="mr-2 text-green-400" size={20} />
                  Social Media & Links
                </CardTitle>
                <p className="text-sm text-gray-400">
                  Connect your social media accounts and external links
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label className="text-base font-medium">Spotify Podcast Link</Label>
                    <Input
                      id="spotify"
                      name="spotify"
                      type="url"
                      defaultValue={settings?.socialLinks?.spotify || ""}
                      placeholder="https://open.spotify.com/show/..."
                      className="bg-deep-dark border-gray-700 mt-2"
                    />
                    <p className="text-xs text-gray-500 mt-1">Link to your Spotify podcast</p>
                  </div>
                  <div>
                    <Label className="text-base font-medium">YouTube Channel</Label>
                    <Input
                      id="youtube"
                      name="youtube"
                      type="url"
                      defaultValue={settings?.socialLinks?.youtube || ""}
                      placeholder="https://youtube.com/@yourchannel"
                      className="bg-deep-dark border-gray-700 mt-2"
                    />
                    <p className="text-xs text-gray-500 mt-1">Link to your YouTube channel</p>
                  </div>
                  <div>
                    <Label className="text-base font-medium">Instagram Profile</Label>
                    <Input
                      id="instagram"
                      name="instagram"
                      type="url"
                      defaultValue={settings?.socialLinks?.instagram || ""}
                      placeholder="https://instagram.com/yourprofile"
                      className="bg-deep-dark border-gray-700 mt-2"
                    />
                    <p className="text-xs text-gray-500 mt-1">Link to your Instagram profile</p>
                  </div>
                  <div>
                    <Label className="text-base font-medium">Twitter/X Profile</Label>
                    <Input
                      id="twitter"
                      name="twitter"
                      type="url"
                      defaultValue={settings?.socialLinks?.twitter || ""}
                      placeholder="https://twitter.com/yourhandle"
                      className="bg-deep-dark border-gray-700 mt-2"
                    />
                    <p className="text-xs text-gray-500 mt-1">Link to your Twitter/X profile</p>
                  </div>
                </div>

                <Separator className="bg-gray-700" />

                <div>
                  <Label className="text-base font-medium mb-4 block">Social Media Preview</Label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {[
                      { name: "Spotify", url: settings?.socialLinks?.spotify, color: "bg-green-500" },
                      { name: "YouTube", url: settings?.socialLinks?.youtube, color: "bg-red-500" },
                      { name: "Instagram", url: settings?.socialLinks?.instagram, color: "bg-pink-500" },
                      { name: "Twitter", url: settings?.socialLinks?.twitter, color: "bg-blue-500" },
                    ].map((platform) => (
                      <div key={platform.name} className="text-center">
                        <div className={`w-full h-12 ${platform.color} rounded-lg mb-2 flex items-center justify-center`}>
                          <span className="text-white text-xs font-medium">{platform.name}</span>
                        </div>
                        <p className="text-xs text-gray-400">
                          {platform.url ? "✓ Connected" : "Not linked"}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Payments Tab */}
          <TabsContent value="payments" className="space-y-6">
            <Card className="bg-dark-surface">
              <CardHeader>
                <CardTitle className="text-text-light flex items-center">
                  <CreditCard className="mr-2 text-yellow-400" size={20} />
                  Donations & Payments
                </CardTitle>
                <p className="text-sm text-gray-400">
                  Set up Stripe payments for donations and merchandise
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label className="text-base font-medium">Stripe Public Key</Label>
                    <Input
                      id="stripePublicKey"
                      name="stripePublicKey"
                      defaultValue={settings?.stripePublicKey || ""}
                      placeholder="pk_live_... or pk_test_..."
                      className="bg-deep-dark border-gray-700 mt-2"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Get this from your Stripe dashboard (safe to be public)
                    </p>
                  </div>
                  <div>
                    <Label className="text-base font-medium">Monthly Donation Goal ($)</Label>
                    <Input
                      id="donationGoal"
                      name="donationGoal"
                      type="number"
                      defaultValue={settings?.donationGoal || 1000}
                      placeholder="1000"
                      className="bg-deep-dark border-gray-700 mt-2"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Target amount for monthly supporter goals
                    </p>
                  </div>
                </div>

                <Separator className="bg-gray-700" />

                <div>
                  <Label className="text-base font-medium mb-4 block">Payment Features</Label>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-4 bg-deep-dark rounded-lg">
                      <div>
                        <p className="text-sm font-medium text-text-light">One-time Donations</p>
                        <p className="text-xs text-gray-400">Allow supporters to make one-time contributions</p>
                      </div>
                      <Switch defaultChecked={true} />
                    </div>
                    <div className="flex items-center justify-between p-4 bg-deep-dark rounded-lg">
                      <div>
                        <p className="text-sm font-medium text-text-light">Monthly Subscriptions</p>
                        <p className="text-xs text-gray-400">Enable recurring monthly support</p>
                      </div>
                      <Switch defaultChecked={false} />
                    </div>
                    <div className="flex items-center justify-between p-4 bg-deep-dark rounded-lg">
                      <div>
                        <p className="text-sm font-medium text-text-light">Merchandise Sales</p>
                        <p className="text-xs text-gray-400">Sell branded merchandise and products</p>
                      </div>
                      <Switch defaultChecked={false} />
                    </div>
                  </div>
                </div>

                <div>
                  <Label className="text-base font-medium mb-4 block">Donation Progress</Label>
                  <div className="bg-deep-dark rounded-lg p-6">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm text-gray-400">Monthly Goal Progress</span>
                      <span className="text-sm font-medium text-text-light">$250 / $1,000</span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-3">
                      <div 
                        className="h-3 rounded-full"
                        style={{ 
                          backgroundColor: settings?.primaryColor || "#3B82F6",
                          width: "25%" 
                        }}
                      />
                    </div>
                    <p className="text-xs text-gray-500 mt-2">25% of monthly goal reached</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </form>
      </Tabs>
    </div>
  );
}