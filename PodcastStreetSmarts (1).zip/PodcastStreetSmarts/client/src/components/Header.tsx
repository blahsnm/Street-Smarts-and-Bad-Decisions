import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Menu, X, Mic, Settings, LogIn, LogOut } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [location] = useLocation();
  const { user, isAuthenticated, isAdmin } = useAuth();

  const navigation = [
    { name: "Home", href: "/" },
    { name: "Videos", href: "/videos" },
    { name: "Photography", href: "/photography" },
    { name: "Street Smarts", href: "/street-smarts" },
    { name: "Bad Decisions", href: "/bad-decisions" },
    { name: "Forum", href: "/forum" },
    { name: "About", href: "/about" },
  ];

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <header className="fixed top-0 w-full bg-deep-dark/95 backdrop-blur-sm border-b border-dark-surface z-50">
      <nav className="container mx-auto px-4 py-4 flex justify-between items-center">
        {/* Logo */}
        <Link href="/" className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-r from-light-blue to-accent-blue rounded-lg flex items-center justify-center">
            <Mic className="text-white" size={20} />
          </div>
          <div className="hidden md:block">
            <h1 className="text-xl font-bold text-text-light">Street Smarts & Bad Decisions</h1>
            <p className="text-sm text-gray-400">Podcast & Photography</p>
          </div>
        </Link>

        {/* Hamburger Menu Button */}
        <Button
          variant="ghost"
          size="sm"
          className="md:hidden relative z-50 w-8 h-8 p-0"
          onClick={toggleMobileMenu}
        >
          {isMobileMenuOpen ? (
            <X className="text-text-light" size={20} />
          ) : (
            <Menu className="text-text-light" size={20} />
          )}
        </Button>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-8">
          {navigation.map((item) => (
            <Link
              key={item.name}
              href={item.href}
              className={`transition-colors duration-300 ${
                location === item.href
                  ? "text-text-light"
                  : "text-gray-300 hover:text-accent-blue"
              }`}
            >
              {item.name}
            </Link>
          ))}
          
          {/* Donate Button Only */}
          <div className="flex items-center space-x-4">
            <Link href="/donate">
              <Button className="bg-light-blue hover:bg-accent-blue">
                Donate
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Mobile Navigation Dropdown */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-dark-surface/95 backdrop-blur-sm border-t border-gray-700">
          <div className="container mx-auto px-4 py-4 space-y-4">
            {navigation.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className={`block py-2 transition-colors duration-300 ${
                  location === item.href
                    ? "text-text-light"
                    : "text-gray-300 hover:text-accent-blue"
                }`}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {item.name}
              </Link>
            ))}
            
            {/* Mobile Donate Button */}
            
            <Link href="/donate" onClick={() => setIsMobileMenuOpen(false)}>
              <Button className="w-full bg-light-blue hover:bg-accent-blue">
                Donate
              </Button>
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
