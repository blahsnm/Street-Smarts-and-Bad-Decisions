import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { MessageCircle, Users, TrendingUp, Clock, Reply, Bell, Heart, Play, Mail, Check } from "lucide-react";
import type { ForumPost } from "@shared/schema";

export default function Forum() {
  const { data: posts, isLoading } = useQuery<ForumPost[]>({
    queryKey: ["/api/forum"],
  });

  const [showEmailForm, setShowEmailForm] = useState(false);
  const [email, setEmail] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);

  useEffect(() => {
    document.title = "Community Forum - Street Smarts & Bad Decisions";
  }, []);

  const handleNotificationSignup = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      setIsSubmitted(true);
      // Here you could integrate with an email service like Mailchimp, ConvertKit, etc.
      setTimeout(() => {
        setShowEmailForm(false);
        setIsSubmitted(false);
        setEmail("");
      }, 3000);
    }
  };

  // Real discussions will be loaded from the database

  const displayPosts = posts || [];

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "street-smarts": return "bg-green-500/20 text-green-400";
      case "bad-decisions": return "bg-red-500/20 text-red-400";
      case "photography": return "bg-blue-500/20 text-blue-400";
      default: return "bg-gray-500/20 text-gray-400";
    }
  };

  const getCategoryName = (category: string) => {
    switch (category) {
      case "street-smarts": return "Street Smarts";
      case "bad-decisions": return "Bad Decision";
      case "photography": return "Photography";
      default: return "General";
    }
  };

  const getInitials = (username: string) => {
    return username.split('_').map(word => word[0]).join('').toUpperCase();
  };

  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(hours / 24);

    if (days > 0) return `${days} day${days > 1 ? 's' : ''} ago`;
    if (hours > 0) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    return 'Just now';
  };

  if (isLoading) {
    return (
      <div className="py-20 bg-deep-dark min-h-screen">
        <div className="container mx-auto px-4">
          <Skeleton className="h-12 w-96 mx-auto mb-4" />
          <Skeleton className="h-6 w-128 mx-auto mb-16" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            {[...Array(3)].map((_, i) => (
              <Card key={i} className="bg-dark-surface">
                <CardContent className="p-6 text-center">
                  <Skeleton className="h-8 w-16 mx-auto mb-2" />
                  <Skeleton className="h-4 w-24 mx-auto" />
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="space-y-6">
            {[...Array(5)].map((_, i) => (
              <Card key={i} className="bg-dark-surface">
                <CardContent className="p-6">
                  <Skeleton className="h-6 w-3/4 mb-4" />
                  <Skeleton className="h-16 w-full mb-4" />
                  <div className="flex items-center space-x-4">
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-4 w-16" />
                    <Skeleton className="h-4 w-20" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="py-20 bg-deep-dark min-h-screen">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-text-light">Open Forum</h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">Join the conversation. Share your stories, ask questions, and connect with fellow urban navigators.</p>
        </div>

        <div className="max-w-4xl mx-auto">
          {/* Join Community Section */}
          <div className="mb-12">
            <Card className="bg-gradient-to-r from-light-blue/10 to-accent-blue/10 border-light-blue/20">
              <CardContent className="p-8">
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-r from-light-blue to-accent-blue rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <Users className="text-white" size={32} />
                  </div>
                  <h2 className="text-2xl font-bold text-text-light mb-4">Welcome to the Community</h2>
                  <p className="text-gray-400 mb-6 max-w-2xl mx-auto">
                    Connect with fellow urban navigators, share your experiences, and learn from each other's 
                    street smarts and spectacular failures.
                  </p>
                  {!showEmailForm && !isSubmitted ? (
                    <div className="flex flex-col sm:flex-row gap-4 justify-center">
                      <Button 
                        size="lg" 
                        className="bg-green-500 hover:bg-green-400"
                        onClick={() => setShowEmailForm(true)}
                      >
                        <Bell className="mr-2" size={16} />
                        Get Notified When Forum Opens
                      </Button>
                      <div className="relative">
                        <Link href="/videos">
                          <Button variant="outline" size="lg" className="border-light-blue text-light-blue hover:bg-light-blue hover:text-white">
                            <Play className="mr-2" size={16} />
                            Browse Latest Content
                          </Button>
                        </Link>
                      </div>
                    </div>
                  ) : showEmailForm && !isSubmitted ? (
                    <form onSubmit={handleNotificationSignup} className="max-w-md mx-auto">
                      <div className="flex flex-col gap-4">
                        <div className="flex gap-2">
                          <div className="relative flex-1">
                            <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
                            <Input
                              type="email"
                              placeholder="Enter your email address"
                              value={email}
                              onChange={(e) => setEmail(e.target.value)}
                              className="pl-10 bg-dark-surface border-gray-600 text-white"
                              required
                            />
                          </div>
                          <Button 
                            type="submit" 
                            className="bg-green-500 hover:bg-green-400"
                            disabled={!email.trim()}
                          >
                            Submit
                          </Button>
                        </div>
                        <Button 
                          type="button" 
                          variant="ghost" 
                          onClick={() => setShowEmailForm(false)}
                          className="text-gray-400 hover:text-white"
                        >
                          Cancel
                        </Button>
                      </div>
                    </form>
                  ) : (
                    <div className="text-center">
                      <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Check className="text-green-400" size={24} />
                      </div>
                      <h3 className="text-lg font-semibold text-text-light mb-2">
                        You will be notified when the forum opens. Thank you for joining!
                      </h3>
                      <p className="text-gray-400 text-sm">
                        We'll send you an email as soon as the community forum is ready.
                      </p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Community Features Preview */}
          <div className="mb-12">
            <h2 className="text-2xl font-bold text-text-light mb-6 text-center">What's Coming to the Community</h2>
            <div className="grid md:grid-cols-3 gap-6">
              <Card className="bg-dark-surface text-center">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <MessageCircle className="text-green-400" size={24} />
                  </div>
                  <h3 className="font-semibold text-text-light mb-2">Discussion Threads</h3>
                  <p className="text-gray-400 text-sm">Share stories, ask questions, and get advice from the community</p>
                </CardContent>
              </Card>
              <Card className="bg-dark-surface text-center">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <Heart className="text-blue-400" size={24} />
                  </div>
                  <h3 className="font-semibold text-text-light mb-2">Story Sharing</h3>
                  <p className="text-gray-400 text-sm">Post your own street smarts and bad decisions for others to learn from</p>
                </CardContent>
              </Card>
              <Card className="bg-dark-surface text-center">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-purple-500/20 rounded-xl flex items-center justify-center mx-auto mb-4">
                    <Users className="text-purple-400" size={24} />
                  </div>
                  <h3 className="font-semibold text-text-light mb-2">Member Connections</h3>
                  <p className="text-gray-400 text-sm">Connect with like-minded urban navigators in your area</p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Community Forum Coming Soon */}
          <Card className="bg-dark-surface">
            <CardContent className="p-8">
              <div className="text-center py-16">
                <div className="w-24 h-24 bg-light-blue/20 rounded-full flex items-center justify-center mx-auto mb-6">
                  <MessageCircle className="text-light-blue" size={48} />
                </div>
                <h3 className="text-xl font-semibold text-text-light mb-2">Community Forum Coming Soon</h3>
                <p className="text-gray-400 mb-6">
                  Malissa is setting up the community space for discussions and stories.
                </p>
                <p className="text-gray-500 text-sm mb-6">
                  Check back soon to share your street smarts and bad decisions with the community.
                </p>
                
                {/* Quick Access Links */}
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Link href="/street-smarts">
                    <Button variant="outline" className="border-green-500 text-green-400 hover:bg-green-500 hover:text-white">
                      Explore Street Smarts
                    </Button>
                  </Link>
                  <Link href="/bad-decisions">
                    <Button variant="outline" className="border-red-500 text-red-400 hover:bg-red-500 hover:text-white">
                      Learn from Bad Decisions
                    </Button>
                  </Link>
                  <Link href="/photography">
                    <Button variant="outline" className="border-blue-500 text-blue-400 hover:bg-blue-500 hover:text-white">
                      View Photography
                    </Button>
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
