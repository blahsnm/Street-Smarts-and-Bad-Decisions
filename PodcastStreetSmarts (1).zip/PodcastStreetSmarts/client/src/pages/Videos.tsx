import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Play, Heart, Clock, Calendar, Filter, Grid, List } from "lucide-react";
import type { Video } from "@shared/schema";

export default function Videos() {
  const { data: videos, isLoading } = useQuery<Video[]>({
    queryKey: ["/api/videos"],
  });

  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  useEffect(() => {
    document.title = "Latest Episodes - Street Smarts & Bad Decisions";
  }, []);

  const categories = [
    { id: "all", name: "All Content", count: videos?.length || 0 },
    { id: "street-smarts", name: "Street Smarts", count: videos?.filter(v => v.category === "street-smarts").length || 0 },
    { id: "bad-decisions", name: "Bad Decisions", count: videos?.filter(v => v.category === "bad-decisions").length || 0 },
    { id: "photography", name: "Photography", count: videos?.filter(v => v.category === "photography").length || 0 },
  ];

  const filteredVideos = selectedCategory === "all" 
    ? videos || [] 
    : videos?.filter(video => video.category === selectedCategory) || [];

  if (isLoading) {
    return (
      <div className="py-20 bg-dark-surface min-h-screen">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <Skeleton className="h-12 w-96 mx-auto mb-4" />
            <Skeleton className="h-6 w-128 mx-auto" />
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="bg-deep-dark">
                <Skeleton className="aspect-video w-full" />
                <CardContent className="p-4">
                  <Skeleton className="h-6 w-full mb-2" />
                  <Skeleton className="h-4 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-1/2" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="py-20 bg-dark-surface min-h-screen">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-text-light">Browse All Content</h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">Dive into our complete collection of episodes, stories, and insights</p>
        </div>

        {/* Content Categories Filter */}
        <div className="mb-12">
          <div className="flex flex-wrap justify-center gap-4">
            {categories.map((category) => (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? "default" : "outline"}
                onClick={() => setSelectedCategory(category.id)}
                className={`${
                  selectedCategory === category.id
                    ? "bg-light-blue hover:bg-accent-blue text-white"
                    : "border-gray-600 text-gray-400 hover:bg-gray-700 hover:text-white"
                }`}
              >
                <Filter className="mr-2" size={16} />
                {category.name} ({category.count})
              </Button>
            ))}
          </div>
        </div>

        {/* Featured Video */}
        {filteredVideos && filteredVideos.length > 0 && (
          <div className="mb-16">
            <Card className="max-w-4xl mx-auto bg-deep-dark shadow-2xl">
              <div className="aspect-video relative">
                <img 
                  src={filteredVideos[0].thumbnail || "https://images.unsplash.com/photo-1516280440614-37939bbacd81?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=675"} 
                  alt={filteredVideos[0].title} 
                  className="w-full h-full object-cover rounded-t-lg"
                />
                <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                  <Button size="lg" className="w-20 h-20 bg-light-blue hover:bg-accent-blue rounded-full">
                    <Play className="text-white ml-1" size={24} />
                  </Button>
                </div>
              </div>
              <CardContent className="p-6">
                <h2 className="text-2xl font-bold mb-2 text-text-light">{filteredVideos[0].title}</h2>
                <p className="text-gray-400 mb-4">{filteredVideos[0].description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-accent-blue font-semibold flex items-center">
                    <Clock className="mr-1" size={16} />
                    {filteredVideos[0].duration || "45:32"}
                  </span>
                  <div className="flex items-center space-x-4">
                    <span className="text-gray-500 text-sm flex items-center">
                      <Calendar className="mr-1" size={16} />
                      2 days ago
                    </span>
                    <div className="flex items-center space-x-2">
                      <Heart className="text-red-500" size={16} />
                      <span className="text-gray-400">1.2k</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Video Grid */}
        {filteredVideos && filteredVideos.length > 1 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredVideos.slice(1).map((video) => (
              <Card key={video.id} className="bg-deep-dark hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2">
                <div className="aspect-video relative">
                  <img 
                    src={video.thumbnail || "https://images.unsplash.com/photo-1516280440614-37939bbacd81?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=338"} 
                    alt={video.title} 
                    className="w-full h-full object-cover rounded-t-lg"
                  />
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity duration-300">
                    <Button className="w-12 h-12 bg-light-blue rounded-full">
                      <Play className="text-white ml-0.5" size={16} />
                    </Button>
                  </div>
                  <span className="absolute bottom-2 right-2 bg-black/70 px-2 py-1 rounded text-sm text-white">
                    {video.duration || "28:45"}
                  </span>
                </div>
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-2 text-text-light">{video.title}</h3>
                  <p className="text-gray-400 text-sm mb-2">{video.description}</p>
                  <span className="text-gray-500 text-xs">5 days ago</span>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : !isLoading && (
          <div className="text-center py-16">
            <div className="w-24 h-24 mx-auto mb-6 bg-gradient-to-r from-light-blue to-accent-blue rounded-full flex items-center justify-center opacity-50">
              <Play className="text-white" size={32} />
            </div>
            <h3 className="text-2xl font-bold text-text-light mb-4">
              {selectedCategory === "all" ? "No Episodes Yet" : `No ${categories.find(c => c.id === selectedCategory)?.name} Content`}
            </h3>
            <p className="text-gray-400 mb-8">
              {selectedCategory === "all" 
                ? "We're working on creating amazing content for you. Check back soon!" 
                : "Check out other categories or come back later for new content in this section."}
            </p>
            {selectedCategory !== "all" && (
              <Button 
                onClick={() => setSelectedCategory("all")}
                variant="outline" 
                className="border-light-blue text-light-blue hover:bg-light-blue hover:text-white"
              >
                View All Content
              </Button>
            )}
          </div>
        )}

        {filteredVideos && filteredVideos.length > 0 && (
          <div className="text-center mt-12">
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/forum">
                <Button className="bg-light-blue hover:bg-accent-blue px-8 py-3">
                  Join Community Discussion
                </Button>
              </Link>
              <Link href="/photography">
                <Button variant="outline" className="border-light-blue text-light-blue hover:bg-light-blue hover:text-white px-8 py-3">
                  View Photography
                </Button>
              </Link>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
