import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Settings, 
  Video, 
  Camera, 
  MessageCircle, 
  Users, 
  BarChart3,
  Upload,
  Edit,
  Trash2,
  Plus,
  Layout,
  FolderOpen
} from "lucide-react";
import { Link } from "wouter";
import AdminVideos from "@/components/admin/AdminVideos";
import AdminPhotos from "@/components/admin/AdminPhotos";
import AdminSettings from "@/components/admin/AdminSettings";
import AdminForum from "@/components/admin/AdminForum";
import AdminDashboard from "@/components/admin/AdminDashboard";
import VisualEditor from "@/components/admin/VisualEditor";
import CommentManager from "@/components/admin/CommentManager";
import TextEditor from "@/components/admin/TextEditor";
import FileManager from "@/components/admin/FileManager";

export default function Admin() {
  const { user, isLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("dashboard");
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [checkingAdmin, setCheckingAdmin] = useState(true);

  useEffect(() => {
    document.title = "Admin Dashboard - Street Smarts & Bad Decisions";
  }, []);

  // Check if admin is authenticated via session
  useEffect(() => {
    const checkAdminAuth = async () => {
      try {
        const response = await fetch('/api/admin/check', {
          method: 'GET',
          credentials: 'include'
        });
        
        if (response.ok) {
          setIsAdminAuthenticated(true);
        } else {
          setIsAdminAuthenticated(false);
        }
      } catch (error) {
        setIsAdminAuthenticated(false);
      } finally {
        setCheckingAdmin(false);
      }
    };

    checkAdminAuth();
  }, []);

  // Redirect to admin login if not authenticated
  useEffect(() => {
    if (!checkingAdmin && !isAdminAuthenticated) {
      toast({
        title: "Access Denied",
        description: "Please log in to access the admin dashboard",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/admin/login";
      }, 500);
      return;
    }
  }, [isAdminAuthenticated, checkingAdmin, toast]);

  if (isLoading || checkingAdmin) {
    return (
      <div className="min-h-screen bg-deep-dark flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-deep-dark py-4 sm:py-8 lg:py-20">
      <div className="container mx-auto px-2 sm:px-4 lg:px-6">
        {/* Mobile-First Responsive Header */}
        <div className="mb-4 sm:mb-6 lg:mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="text-center sm:text-left">
              <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-text-light mb-2">
                Admin Dashboard
              </h1>
              <p className="text-sm sm:text-base text-gray-400">
                Welcome Malissa. Complete control over your podcast website.
              </p>
              <p className="text-xs text-gray-500 mt-1 hidden sm:block">
                Direct admin access URL: {window.location.origin}/admin
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-2 sm:gap-4">
              <Link href="/">
                <Button 
                  variant="outline" 
                  className="w-full sm:w-auto border-accent-blue text-accent-blue hover:bg-accent-blue hover:text-white"
                >
                  View Site
                </Button>
              </Link>
              <Button 
                variant="outline" 
                className="w-full sm:w-auto border-red-500 text-red-400 hover:bg-red-500 hover:text-white"
                onClick={async () => {
                  try {
                    await fetch('/api/admin/logout', { method: 'POST', credentials: 'include' });
                    window.location.href = "/admin/login";
                  } catch (error) {
                    console.error('Logout failed:', error);
                  }
                }}
              >
                Logout
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile-First Responsive Admin Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          {/* Mobile: Scrollable horizontal tabs */}
          <div className="sm:hidden">
            <TabsList className="flex w-full overflow-x-auto bg-dark-surface text-xs p-1 space-x-1">
              <TabsTrigger value="dashboard" className="flex-shrink-0 data-[state=active]:bg-light-blue px-3 py-2">
                <BarChart3 className="mr-1" size={14} />
                <span className="hidden xs:block">Dashboard</span>
              </TabsTrigger>
              <TabsTrigger value="videos" className="flex-shrink-0 data-[state=active]:bg-light-blue px-3 py-2">
                <Video className="mr-1" size={14} />
                <span className="hidden xs:block">Videos</span>
              </TabsTrigger>
              <TabsTrigger value="photos" className="flex-shrink-0 data-[state=active]:bg-light-blue px-3 py-2">
                <Camera className="mr-1" size={14} />
                <span className="hidden xs:block">Photos</span>
              </TabsTrigger>
              <TabsTrigger value="forum" className="flex-shrink-0 data-[state=active]:bg-light-blue px-3 py-2">
                <MessageCircle className="mr-1" size={14} />
                <span className="hidden xs:block">Forum</span>
              </TabsTrigger>
              <TabsTrigger value="settings" className="flex-shrink-0 data-[state=active]:bg-light-blue px-3 py-2">
                <Settings className="mr-1" size={14} />
                <span className="hidden xs:block">Settings</span>
              </TabsTrigger>
            </TabsList>
          </div>

          {/* Desktop: Full grid tabs */}
          <div className="hidden sm:block">
            <TabsList className="grid w-full grid-cols-4 lg:grid-cols-9 bg-dark-surface text-xs">
              <TabsTrigger value="dashboard" className="data-[state=active]:bg-light-blue">
                <BarChart3 className="mr-1" size={14} />
                Dashboard
              </TabsTrigger>
              <TabsTrigger value="editor" className="data-[state=active]:bg-light-blue lg:flex hidden">
                <Layout className="mr-1" size={14} />
                Visual
              </TabsTrigger>
              <TabsTrigger value="text" className="data-[state=active]:bg-light-blue lg:flex hidden">
                <Edit className="mr-1" size={14} />
                Text
              </TabsTrigger>
              <TabsTrigger value="files" className="data-[state=active]:bg-light-blue lg:flex hidden">
                <FolderOpen className="mr-1" size={14} />
                Files
              </TabsTrigger>
              <TabsTrigger value="videos" className="data-[state=active]:bg-light-blue">
                <Video className="mr-1" size={14} />
                Videos
              </TabsTrigger>
              <TabsTrigger value="photos" className="data-[state=active]:bg-light-blue">
                <Camera className="mr-1" size={14} />
                Photos
              </TabsTrigger>
              <TabsTrigger value="forum" className="data-[state=active]:bg-light-blue">
                <MessageCircle className="mr-1" size={14} />
                Forum
              </TabsTrigger>
              <TabsTrigger value="comments" className="data-[state=active]:bg-light-blue lg:flex hidden">
                <Users className="mr-1" size={14} />
                Comments
              </TabsTrigger>
              <TabsTrigger value="settings" className="data-[state=active]:bg-light-blue">
                <Settings className="mr-1" size={14} />
                Settings
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="dashboard">
            <AdminDashboard onTabSwitch={setActiveTab} />
          </TabsContent>

          <TabsContent value="editor">
            <VisualEditor 
              page="home" 
              onSave={(content) => {
                console.log('Saving page content:', content);
                toast({
                  title: "Success",
                  description: "Page content saved successfully!",
                });
              }} 
            />
          </TabsContent>

          <TabsContent value="text">
            <TextEditor 
              onSave={(textContent) => {
                console.log('Saving text content:', textContent);
                toast({
                  title: "Success",
                  description: "All text content updated successfully!",
                });
              }} 
            />
          </TabsContent>

          <TabsContent value="files">
            <FileManager />
          </TabsContent>

          <TabsContent value="videos">
            <AdminVideos />
          </TabsContent>

          <TabsContent value="photos">
            <AdminPhotos />
          </TabsContent>

          <TabsContent value="forum">
            <AdminForum />
          </TabsContent>

          <TabsContent value="comments">
            <CommentManager />
          </TabsContent>

          <TabsContent value="settings">
            <AdminSettings />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}