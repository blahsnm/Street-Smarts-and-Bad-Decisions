import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";
import { Coffee, Heart, Star, Share2, MessageCircle, Users, BookOpen, DollarSign } from "lucide-react";

export default function Donate() {
  const { toast } = useToast();
  const [customAmount, setCustomAmount] = useState("");
  const [showPayPalUrl, setShowPayPalUrl] = useState<string | null>(null);

  useEffect(() => {
    document.title = "Support Our Project - Street Smarts & Bad Decisions";
  }, []);

  const donateMutation = useMutation({
    mutationFn: async (amount: number) => {
      const response = await apiRequest("POST", "/api/donate", { amount });
      if (!response.ok) {
        throw new Error('Failed to create donation');
      }
      return response.json();
    },
    onSuccess: (data) => {
      console.log('Donation response:', data);
      if (data.approvalUrl) {
        // Try to open PayPal in a new tab first
        const newWindow = window.open(data.approvalUrl, '_blank');
        if (!newWindow || newWindow.closed) {
          // If popup was blocked, show the URL for manual clicking
          setShowPayPalUrl(data.approvalUrl);
          toast({
            title: "PayPal Ready",
            description: "Click the PayPal link below to complete your donation",
          });
        } else {
          toast({
            title: "Redirecting to PayPal",
            description: "Please complete your donation in the new tab",
          });
        }
      } else {
        toast({
          title: "Donation Error",
          description: "PayPal approval URL not received",
          variant: "destructive",
        });
      }
    },
    onError: (error: any) => {
      console.error('Donation error:', error);
      toast({
        title: "Donation Failed",
        description: error.message || "There was an error processing your donation",
        variant: "destructive",
      });
    },
  });

  const handleDonate = (amount: number) => {
    if (amount <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid donation amount",
        variant: "destructive",
      });
      return;
    }
    console.log('Starting donation for amount:', amount);
    donateMutation.mutate(amount);
  };

  const handleCustomDonate = () => {
    const amount = parseFloat(customAmount);
    if (isNaN(amount) || amount <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid donation amount",
        variant: "destructive",
      });
      return;
    }
    handleDonate(amount);
  };

  return (
    <div className="py-20 bg-deep-dark min-h-screen">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-8 text-text-light">Support the Project</h1>
          <p className="text-xl text-gray-400 mb-12 leading-relaxed">
            Help us keep the conversations going, the cameras clicking, and the stories flowing. 
            Your support helps us create content that matters and build a community that cares.
          </p>

          {/* Donation Options */}
          <div className="grid md:grid-cols-3 gap-6 mb-12">
            <Card className="bg-dark-surface hover:bg-dark-surface/80 transition-colors duration-300">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-green-400 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Coffee className="text-white" size={32} />
                </div>
                <h3 className="text-xl font-bold mb-2 text-text-light">Buy Us Coffee</h3>
                <div className="text-3xl font-bold text-green-400 mb-4">$5</div>
                <p className="text-gray-400 text-sm mb-6">Fuel our late-night editing sessions</p>
                <Button 
                  className="w-full bg-green-500 hover:bg-green-400"
                  onClick={() => handleDonate(5)}
                  disabled={donateMutation.isPending}
                >
                  {donateMutation.isPending ? "Processing..." : "Support Now"}
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-dark-surface hover:bg-dark-surface/80 transition-colors duration-300 border-2 border-accent-blue">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-light-blue to-accent-blue rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Heart className="text-white" size={32} />
                </div>
                <h3 className="text-xl font-bold mb-2 text-text-light">Monthly Support</h3>
                <div className="text-3xl font-bold text-accent-blue mb-4">$15</div>
                <p className="text-gray-400 text-sm mb-2">Become part of our core community</p>
                <div className="text-accent-blue text-sm font-semibold mb-4">Most Popular</div>
                <Button 
                  className="w-full bg-light-blue hover:bg-accent-blue"
                  onClick={() => handleDonate(15)}
                  disabled={donateMutation.isPending}
                >
                  {donateMutation.isPending ? "Processing..." : "Join Monthly"}
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-dark-surface hover:bg-dark-surface/80 transition-colors duration-300">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-purple-400 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Star className="text-white" size={32} />
                </div>
                <h3 className="text-xl font-bold mb-2 text-text-light">Producer Level</h3>
                <div className="text-3xl font-bold text-purple-400 mb-4">$50</div>
                <p className="text-gray-400 text-sm mb-6">Help us upgrade our equipment</p>
                <Button 
                  className="w-full bg-purple-500 hover:bg-purple-400"
                  onClick={() => handleDonate(50)}
                  disabled={donateMutation.isPending}
                >
                  {donateMutation.isPending ? "Processing..." : "Become Producer"}
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* PayPal Link Display (if popup was blocked) */}
          {showPayPalUrl && (
            <div className="mb-12">
              <Card className="bg-blue-900/20 border-blue-500/50 max-w-md mx-auto">
                <CardContent className="p-6 text-center">
                  <h3 className="text-lg font-bold text-blue-300 mb-4">
                    Complete Your Donation
                  </h3>
                  <p className="text-gray-300 text-sm mb-4">
                    Your browser blocked the PayPal popup. Click the button below to complete your donation.
                  </p>
                  <Button 
                    onClick={() => window.open(showPayPalUrl, '_blank')}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    Continue to PayPal
                  </Button>
                  <Button 
                    variant="outline"
                    onClick={() => setShowPayPalUrl(null)}
                    className="w-full mt-2 border-gray-600 text-gray-400"
                  >
                    Cancel
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Custom Amount Option */}
          <div className="mb-12">
            <Card className="bg-dark-surface max-w-md mx-auto">
              <CardContent className="p-8">
                <div className="text-center mb-6">
                  <div className="w-16 h-16 bg-gradient-to-r from-yellow-500 to-yellow-400 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <DollarSign className="text-white" size={32} />
                  </div>
                  <h3 className="text-xl font-bold mb-2 text-text-light">Custom Amount</h3>
                  <p className="text-gray-400 text-sm">Choose your own donation amount</p>
                </div>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="custom-amount" className="text-text-light text-sm">
                      Amount (USD)
                    </Label>
                    <Input
                      id="custom-amount"
                      type="number"
                      min="1"
                      step="0.01"
                      value={customAmount}
                      onChange={(e) => setCustomAmount(e.target.value)}
                      className="bg-deep-dark border-gray-600 text-text-light"
                      placeholder="Enter amount..."
                    />
                  </div>
                  <Button 
                    className="w-full bg-yellow-500 hover:bg-yellow-400 text-black"
                    onClick={handleCustomDonate}
                    disabled={donateMutation.isPending || !customAmount}
                  >
                    {donateMutation.isPending ? "Processing..." : "Donate Custom Amount"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* What Your Support Does */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-text-light mb-8">Where Your Support Goes</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-dark-surface">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="w-10 h-10 bg-light-blue rounded-lg flex items-center justify-center mr-3">
                      <Users className="text-white" size={20} />
                    </div>
                    <h4 className="font-semibold text-text-light">Community Building</h4>
                  </div>
                  <p className="text-gray-400 text-sm">
                    Platform maintenance, forum hosting, and community management tools 
                    that keep our discussions flowing and meaningful.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-dark-surface">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center mr-3">
                      <Coffee className="text-white" size={20} />
                    </div>
                    <h4 className="font-semibold text-text-light">Content Creation</h4>
                  </div>
                  <p className="text-gray-400 text-sm">
                    Recording equipment, editing software, hosting costs, and the 
                    occasional coffee that keeps us going through all-night editing sessions.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-dark-surface">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="w-10 h-10 bg-purple-500 rounded-lg flex items-center justify-center mr-3">
                      <Star className="text-white" size={20} />
                    </div>
                    <h4 className="font-semibold text-text-light">Equipment Upgrades</h4>
                  </div>
                  <p className="text-gray-400 text-sm">
                    Better cameras, microphones, and editing setup to improve the 
                    quality of our podcasts and street photography.
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-dark-surface">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="w-10 h-10 bg-red-500 rounded-lg flex items-center justify-center mr-3">
                      <BookOpen className="text-white" size={20} />
                    </div>
                    <h4 className="font-semibold text-text-light">Growth & Outreach</h4>
                  </div>
                  <p className="text-gray-400 text-sm">
                    Marketing, guest appearances, and expanding our reach to help 
                    more people learn from our collective street smarts and bad decisions.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Alternative Support Methods */}
          <Card className="bg-dark-surface mb-12">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold mb-6 text-text-light">Other Ways to Support</h3>
              <div className="grid md:grid-cols-2 gap-6 text-left">
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-accent-blue rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                    <Share2 className="text-white" size={16} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-text-light mb-1">Share Our Content</h4>
                    <p className="text-gray-400 text-sm">Help others discover our stories by sharing episodes and photos on social media</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-accent-blue rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                    <MessageCircle className="text-white" size={16} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-text-light mb-1">Join Discussions</h4>
                    <p className="text-gray-400 text-sm">Engage with our community and add your voice to the conversation</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-accent-blue rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                    <BookOpen className="text-white" size={16} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-text-light mb-1">Share Your Story</h4>
                    <p className="text-gray-400 text-sm">Contribute to our content by sharing your own street smarts or bad decisions</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-accent-blue rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                    <Star className="text-white" size={16} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-text-light mb-1">Leave Reviews</h4>
                    <p className="text-gray-400 text-sm">Help us reach more people by leaving reviews on podcast platforms</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Thank You Message */}
          <div className="bg-gradient-to-r from-light-blue/10 to-accent-blue/10 rounded-2xl p-8 mb-8">
            <h3 className="text-2xl font-bold text-text-light mb-4">Thank You!</h3>
            <p className="text-gray-400 leading-relaxed">
              Whether you support us financially, share our content, or just listen to our stories, 
              you're part of what makes this community special. Every coffee, every share, every 
              comment helps us continue building a space where people can be real about their 
              experiences and learn from each other.
            </p>
          </div>

          {/* Final CTA */}
          <div className="text-center">
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-light-blue hover:bg-accent-blue">
                <Heart className="mr-2" size={20} />
                Support Now
              </Button>
              <Button variant="outline" size="lg" className="border-2 border-accent-blue text-accent-blue hover:bg-accent-blue hover:text-white">
                Learn More
              </Button>
            </div>
            <p className="text-gray-500 text-sm mt-6">
              All contributions help us create better content and build a stronger community.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
