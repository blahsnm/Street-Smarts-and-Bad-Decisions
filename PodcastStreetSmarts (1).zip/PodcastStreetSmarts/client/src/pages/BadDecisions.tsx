import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertTriangle, TrendingDown, MessageCircle, BookOpen } from "lucide-react";
import type { Video } from "@shared/schema";

export default function BadDecisions() {
  const { data: videos, isLoading } = useQuery<Video[]>({
    queryKey: ["/api/videos"],
  });

  useEffect(() => {
    document.title = "Bad Decisions - Learning from Mistakes | Street Smarts & Bad Decisions";
  }, []);

  const badDecisionVideos = videos?.filter(video => video.category === "bad-decisions") || [];

  // Real content will be loaded from the database

  if (isLoading) {
    return (
      <div className="py-20 bg-deep-dark min-h-screen">
        <div className="container mx-auto px-4">
          <Skeleton className="h-12 w-96 mx-auto mb-4" />
          <Skeleton className="h-6 w-128 mx-auto mb-16" />
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="bg-dark-surface">
                <CardContent className="p-6">
                  <Skeleton className="h-6 w-full mb-4" />
                  <Skeleton className="h-16 w-full mb-4" />
                  <Skeleton className="h-8 w-24" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="py-20 bg-deep-dark min-h-screen">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-r from-red-500 to-red-400 rounded-2xl flex items-center justify-center mr-4">
              <AlertTriangle className="text-white" size={32} />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-text-light">Bad Decisions</h1>
          </div>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto leading-relaxed">
            Sometimes the best lessons come from the worst choices. We share stories of spectacular 
            failures, costly mistakes, and the wisdom that emerges from chaos.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-16">
          <Card className="bg-dark-surface text-center">
            <CardContent className="p-6">
              <TrendingDown className="w-8 h-8 text-red-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-text-light mb-1">{badDecisionVideos.length}</div>
              <div className="text-gray-400 text-sm">Stories Shared</div>
            </CardContent>
          </Card>
          <Card className="bg-dark-surface text-center">
            <CardContent className="p-6">
              <MessageCircle className="w-8 h-8 text-red-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-text-light mb-1">0</div>
              <div className="text-gray-400 text-sm">Comments</div>
            </CardContent>
          </Card>
          <Card className="bg-dark-surface text-center">
            <CardContent className="p-6">
              <BookOpen className="w-8 h-8 text-red-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-text-light mb-1">0</div>
              <div className="text-gray-400 text-sm">Lessons Learned</div>
            </CardContent>
          </Card>
          <Card className="bg-dark-surface text-center">
            <CardContent className="p-6">
              <AlertTriangle className="w-8 h-8 text-red-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-text-light mb-1">$0</div>
              <div className="text-gray-400 text-sm">Total Cost</div>
            </CardContent>
          </Card>
        </div>

        {/* Featured Bad Decisions */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-text-light mb-8">Hall of Fame Bad Decisions</h2>
          <div className="text-center py-16">
            <div className="w-24 h-24 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <AlertTriangle className="text-red-400" size={48} />
            </div>
            <h3 className="text-xl font-semibold text-text-light mb-2">Bad Decision Stories Coming Soon</h3>
            <p className="text-gray-400 mb-6">
              Malissa will be sharing real stories and lessons learned from life's mistakes.
            </p>
            <p className="text-gray-500 text-sm">
              Check back for honest tales of missteps and the wisdom gained from them.
            </p>
          </div>
        </div>

        {/* Video Episodes */}
        {badDecisionVideos.length > 0 && (
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-text-light mb-8">Video Confessions</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {badDecisionVideos.map((video) => (
                <Card key={video.id} className="bg-dark-surface hover:shadow-xl transition-all duration-300">
                  <div className="aspect-video relative">
                    <img 
                      src={video.thumbnail || "https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=338"} 
                      alt={video.title} 
                      className="w-full h-full object-cover rounded-t-lg"
                    />
                    <span className="absolute bottom-2 right-2 bg-black/70 px-2 py-1 rounded text-sm text-white">
                      {video.duration || "32:15"}
                    </span>
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold mb-2 text-text-light">{video.title}</h3>
                    <p className="text-gray-400 text-sm">{video.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Wisdom Section */}
        <div className="bg-gradient-to-r from-red-500/10 to-red-400/10 rounded-2xl p-8 mb-16">
          <h2 className="text-2xl font-bold text-text-light mb-4">The Silver Lining</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-white font-bold">1</span>
              </div>
              <h4 className="font-semibold text-text-light mb-2">Embrace the Fail</h4>
              <p className="text-gray-400 text-sm">Every mistake is data for better decisions</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-white font-bold">2</span>
              </div>
              <h4 className="font-semibold text-text-light mb-2">Share the Story</h4>
              <p className="text-gray-400 text-sm">Your failure might save someone else</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-3">
                <span className="text-white font-bold">3</span>
              </div>
              <h4 className="font-semibold text-text-light mb-2">Level Up</h4>
              <p className="text-gray-400 text-sm">Use lessons learned for future wins</p>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center bg-gradient-to-r from-red-500/10 to-red-400/10 rounded-2xl p-12">
          <h2 className="text-3xl font-bold text-text-light mb-4">Got a Bad Decision Story?</h2>
          <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
            Share your spectacular failure with our community. Your story could help someone else 
            avoid the same mistake, or at least feel better about their own.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/forum">
              <Button size="lg" className="bg-red-500 hover:bg-red-400">
                Share Your Story
              </Button>
            </Link>
            <Link href="/forum">
              <Button variant="outline" size="lg" className="border-red-500 text-red-400 hover:bg-red-500 hover:text-white">
                Browse All Stories
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
