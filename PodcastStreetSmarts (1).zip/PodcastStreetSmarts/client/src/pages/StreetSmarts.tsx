import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { BookOpen, TrendingUp, Users, Target, Lightbulb } from "lucide-react";
import type { Video } from "@shared/schema";

export default function StreetSmarts() {
  const { data: videos, isLoading } = useQuery<Video[]>({
    queryKey: ["/api/videos"],
  });

  useEffect(() => {
    document.title = "Street Smarts - Practical Urban Wisdom | Street Smarts & Bad Decisions";
  }, []);

  const streetSmartsVideos = videos?.filter(video => video.category === "street-smarts") || [];

  // Real content will be loaded from the database

  if (isLoading) {
    return (
      <div className="py-20 bg-deep-dark min-h-screen">
        <div className="container mx-auto px-4">
          <Skeleton className="h-12 w-96 mx-auto mb-4" />
          <Skeleton className="h-6 w-128 mx-auto mb-16" />
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="bg-dark-surface">
                <CardContent className="p-6">
                  <Skeleton className="h-6 w-full mb-4" />
                  <Skeleton className="h-16 w-full mb-4" />
                  <Skeleton className="h-8 w-24" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="py-20 bg-deep-dark min-h-screen">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-6">
            <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-green-400 rounded-2xl flex items-center justify-center mr-4">
              <BookOpen className="text-white" size={32} />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold text-text-light">Street Smarts</h1>
          </div>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto leading-relaxed">
            Real-world wisdom from the urban jungle. We dive deep into practical life skills, 
            financial literacy, and the unspoken rules of navigating modern city life.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-16">
          <Card className="bg-dark-surface text-center">
            <CardContent className="p-6">
              <TrendingUp className="w-8 h-8 text-green-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-text-light mb-1">{streetSmartsVideos.length}</div>
              <div className="text-gray-400 text-sm">Episodes</div>
            </CardContent>
          </Card>
          <Card className="bg-dark-surface text-center">
            <CardContent className="p-6">
              <Users className="w-8 h-8 text-green-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-text-light mb-1">0</div>
              <div className="text-gray-400 text-sm">Subscribers</div>
            </CardContent>
          </Card>
          <Card className="bg-dark-surface text-center">
            <CardContent className="p-6">
              <Target className="w-8 h-8 text-green-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-text-light mb-1">0%</div>
              <div className="text-gray-400 text-sm">Success Rate</div>
            </CardContent>
          </Card>
          <Card className="bg-dark-surface text-center">
            <CardContent className="p-6">
              <BookOpen className="w-8 h-8 text-green-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-text-light mb-1">0</div>
              <div className="text-gray-400 text-sm">Categories</div>
            </CardContent>
          </Card>
        </div>

        {/* Featured Content */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-text-light mb-8">Featured Street Smarts Content</h2>
          <div className="text-center py-16">
            <div className="w-24 h-24 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Lightbulb className="text-green-400" size={48} />
            </div>
            <h3 className="text-xl font-semibold text-text-light mb-2">Street Smarts Content Coming Soon</h3>
            <p className="text-gray-400 mb-6">
              Malissa will be adding practical wisdom and life strategies here soon.
            </p>
            <p className="text-gray-500 text-sm">
              Check back for real-world insights on navigation, negotiation, and urban survival.
            </p>
          </div>
        </div>

        {/* Video Episodes */}
        {streetSmartsVideos.length > 0 && (
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-text-light mb-8">Latest Episodes</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {streetSmartsVideos.map((video) => (
                <Card key={video.id} className="bg-dark-surface hover:shadow-xl transition-all duration-300">
                  <div className="aspect-video relative">
                    <img 
                      src={video.thumbnail || "https://images.unsplash.com/photo-1556761175-b413da4baf72?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=338"} 
                      alt={video.title} 
                      className="w-full h-full object-cover rounded-t-lg"
                    />
                    <span className="absolute bottom-2 right-2 bg-black/70 px-2 py-1 rounded text-sm text-white">
                      {video.duration || "25:30"}
                    </span>
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold mb-2 text-text-light">{video.title}</h3>
                    <p className="text-gray-400 text-sm">{video.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Call to Action */}
        <div className="text-center bg-gradient-to-r from-green-500/10 to-green-400/10 rounded-2xl p-12">
          <h2 className="text-3xl font-bold text-text-light mb-4">Ready to Level Up Your Street Smarts?</h2>
          <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
            Join our community of urban navigators who are mastering the art of city living, 
            one smart decision at a time.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/forum">
              <Button size="lg" className="bg-green-500 hover:bg-green-400">
                Join Community
              </Button>
            </Link>
            <Link href="/videos">
              <Button variant="outline" size="lg" className="border-green-500 text-green-400 hover:bg-green-500 hover:text-white">
                Browse All Content
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
