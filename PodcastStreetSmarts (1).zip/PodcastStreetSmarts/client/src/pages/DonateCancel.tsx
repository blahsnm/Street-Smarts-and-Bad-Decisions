import { useEffect } from "react";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { XCircle, Home, RotateCcw } from "lucide-react";

export default function DonateCancel() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    document.title = "Donation Cancelled - Street Smarts & Bad Decisions";
  }, []);

  return (
    <div className="min-h-screen bg-deep-dark flex items-center justify-center px-4">
      <Card className="w-full max-w-md bg-dark-surface border-orange-500/20 border-2">
        <CardContent className="p-8 text-center">
          <div className="w-20 h-20 bg-orange-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <XCircle className="text-orange-400" size={48} />
          </div>
          
          <h1 className="text-3xl font-bold text-text-light mb-4">
            Donation Cancelled
          </h1>
          
          <p className="text-gray-300 mb-2">
            Your donation was cancelled.
          </p>
          
          <p className="text-gray-400 text-sm mb-8">
            No charges were made to your account. You can try again anytime.
          </p>

          <div className="space-y-3">
            <Button 
              onClick={() => setLocation("/donate")}
              className="w-full bg-light-blue hover:bg-accent-blue"
            >
              <RotateCcw className="mr-2" size={20} />
              Try Again
            </Button>
            
            <Button 
              onClick={() => setLocation("/")}
              variant="outline"
              className="w-full border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              <Home className="mr-2" size={20} />
              Return to Home
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}