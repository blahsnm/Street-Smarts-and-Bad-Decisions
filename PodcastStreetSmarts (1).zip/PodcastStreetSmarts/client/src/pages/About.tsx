import { useEffect } from "react";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Camera, Mic, Heart, Users, Target, Coffee } from "lucide-react";

export default function About() {
  useEffect(() => {
    document.title = "About Us - Street Smarts & Bad Decisions";
  }, []);

  return (
    <div className="py-20 bg-deep-dark min-h-screen">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-8 text-text-light">About the Project</h1>
          
          <div className="text-center py-16">
            <div className="w-24 h-24 mx-auto mb-6 bg-gradient-to-r from-light-blue to-accent-blue rounded-full flex items-center justify-center opacity-50">
              <Heart className="text-white" size={32} />
            </div>
            <h3 className="text-2xl font-bold text-text-light mb-4">Our Story Coming Soon</h3>
            <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
              Malissa will be sharing the full story behind Street Smarts & Bad Decisions, 
              including the mission, values, and vision for this community.
            </p>
          </div>

          {/* Mission & Values */}
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <Card className="bg-dark-surface">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-light-blue to-accent-blue rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Target className="text-white" size={32} />
                </div>
                <h3 className="text-xl font-bold text-text-light mb-4">Our Mission</h3>
                <p className="text-gray-400">
                  To bridge the gap between academic knowledge and real-world wisdom through authentic storytelling.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-dark-surface">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-green-400 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Heart className="text-white" size={32} />
                </div>
                <h3 className="text-xl font-bold text-text-light mb-4">Our Values</h3>
                <p className="text-gray-400">
                  Authenticity, vulnerability, and learning from both our wins and spectacular failures.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-dark-surface">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-purple-400 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Users className="text-white" size={32} />
                </div>
                <h3 className="text-xl font-bold text-text-light mb-4">Our Community</h3>
                <p className="text-gray-400">
                  Urban navigators who believe that sharing stories makes us all stronger and wiser.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Team Section */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-text-light mb-12">Meet the Creator</h2>
            <div className="text-center py-16">
              <div className="w-24 h-24 mx-auto mb-6 bg-gradient-to-r from-light-blue to-accent-blue rounded-full flex items-center justify-center opacity-50">
                <Users className="text-white" size={32} />
              </div>
              <h3 className="text-2xl font-bold text-text-light mb-4">Team Info Coming Soon</h3>
              <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
                Learn more about Malissa and the creative minds behind this project.
              </p>
            </div>
          </div>



          {/* Contact & Connect */}
          <div className="text-center">
            <h2 className="text-3xl font-bold text-text-light mb-6">Let's Connect</h2>
            <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
              Have a story to share? Questions about urban survival? Want to collaborate? 
              We'd love to hear from you and potentially feature your story.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/forum">
                <Button size="lg" className="bg-light-blue hover:bg-accent-blue">
                  Share Your Story
                </Button>
              </Link>
              <Link href="/forum">
                <Button variant="outline" size="lg" className="border-accent-blue text-accent-blue hover:bg-accent-blue hover:text-white">
                  Join Community
                </Button>
              </Link>
              <Link href="/donate">
                <Button variant="outline" size="lg" className="border-green-500 text-green-400 hover:bg-green-500 hover:text-white">
                  <Coffee className="mr-2" size={16} />
                  Support Us
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
