import { useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Play, Camera, Mic, Heart, Share2, MessageCircle, BookOpen, Star } from "lucide-react";
import { FaSpotify, FaYoutube, FaInstagram, FaTwitter } from "react-icons/fa";

export default function Home() {
  useEffect(() => {
    document.title = "Street Smarts & Bad Decisions - Podcast & Photography";
  }, []);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="min-h-screen flex items-center justify-center relative overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1478737270239-2f02b77fc618?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080" 
            alt="Professional podcast studio setup" 
            className="w-full h-full object-cover opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-deep-dark/80 to-dark-blue/60"></div>
        </div>

        <div className="container mx-auto px-4 relative z-10 text-center">
          <div className="max-w-4xl mx-auto">
            {/* Main Logo Area */}
            <div className="mb-8">
              <div className="w-24 h-24 mx-auto mb-6 bg-gradient-to-r from-light-blue to-accent-blue rounded-2xl flex items-center justify-center shadow-2xl">
                <Mic className="text-white" size={32} />
              </div>
              <h1 className="text-5xl md:text-7xl font-bold mb-4 bg-gradient-to-r from-text-light to-accent-blue bg-clip-text text-transparent">
                Street Smarts & Bad Decisions
              </h1>
              <p className="text-xl md:text-2xl text-gray-300 mb-8">Where wisdom meets chaos in the digital age</p>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Link href="/videos">
                <Button size="lg" className="bg-light-blue hover:bg-accent-blue px-8 py-4 text-lg font-semibold">
                  <Play className="mr-2" size={20} />
                  Watch Latest Episode
                </Button>
              </Link>
              <Link href="/photography">
                <Button variant="outline" size="lg" className="border-2 border-accent-blue text-accent-blue hover:bg-accent-blue hover:text-white px-8 py-4 text-lg font-semibold">
                  <Camera className="mr-2" size={20} />
                  View Photography
                </Button>
              </Link>
            </div>

            {/* Social Media Links */}
            <div className="mt-12 flex justify-center space-x-6">
              <a href="#" className="text-gray-400 hover:text-accent-blue transition-colors duration-300">
                <FaSpotify size={24} />
              </a>
              <a href="#" className="text-gray-400 hover:text-accent-blue transition-colors duration-300">
                <FaYoutube size={24} />
              </a>
              <a href="#" className="text-gray-400 hover:text-accent-blue transition-colors duration-300">
                <FaInstagram size={24} />
              </a>
              <a href="#" className="text-gray-400 hover:text-accent-blue transition-colors duration-300">
                <FaTwitter size={24} />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Content Preview */}
      <section className="py-20 bg-dark-surface">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4 text-text-light">What We're About</h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">Real conversations, authentic stories, and lessons learned the hard way</p>
          </div>

          <div className="grid lg:grid-cols-2 gap-16">
            {/* Street Smarts Preview */}
            <Card className="bg-deep-dark border-green-500/20">
              <CardContent className="p-8">
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-green-400 rounded-xl flex items-center justify-center mr-4">
                    <BookOpen className="text-white" size={24} />
                  </div>
                  <h3 className="text-3xl font-bold text-text-light">Street Smarts</h3>
                </div>
                <p className="text-gray-400 mb-6 text-lg leading-relaxed">
                  Real-world wisdom from the urban jungle. We dive deep into practical life skills, 
                  financial literacy, and the unspoken rules of navigating modern city life.
                </p>
                <Link href="/street-smarts">
                  <Button className="bg-green-500 hover:bg-green-400">
                    Explore Street Smarts
                  </Button>
                </Link>
              </CardContent>
            </Card>

            {/* Bad Decisions Preview */}
            <Card className="bg-deep-dark border-red-500/20">
              <CardContent className="p-8">
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 bg-gradient-to-r from-red-500 to-red-400 rounded-xl flex items-center justify-center mr-4">
                    <Star className="text-white" size={24} />
                  </div>
                  <h3 className="text-3xl font-bold text-text-light">Bad Decisions</h3>
                </div>
                <p className="text-gray-400 mb-6 text-lg leading-relaxed">
                  Sometimes the best lessons come from the worst choices. We share stories of spectacular 
                  failures, costly mistakes, and the wisdom that emerges from chaos.
                </p>
                <Link href="/bad-decisions">
                  <Button className="bg-red-500 hover:bg-red-400">
                    Learn from Mistakes
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Community Stats */}
      <section className="py-20 bg-deep-dark">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-4 text-text-light">Join Our Community</h2>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto">Connect with fellow urban navigators and share your journey</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
            <Card className="bg-dark-surface text-center">
              <CardContent className="p-6">
                <div className="text-3xl font-bold text-accent-blue mb-2">0</div>
                <div className="text-gray-400">Community Members</div>
              </CardContent>
            </Card>
            <Card className="bg-dark-surface text-center">
              <CardContent className="p-6">
                <div className="text-3xl font-bold text-green-400 mb-2">0</div>
                <div className="text-gray-400">Episodes Released</div>
              </CardContent>
            </Card>
            <Card className="bg-dark-surface text-center">
              <CardContent className="p-6">
                <div className="text-3xl font-bold text-red-400 mb-2">0</div>
                <div className="text-gray-400">Stories Shared</div>
              </CardContent>
            </Card>
            <Card className="bg-dark-surface text-center">
              <CardContent className="p-6">
                <div className="text-3xl font-bold text-purple-400 mb-2">0</div>
                <div className="text-gray-400">Photos Captured</div>
              </CardContent>
            </Card>
          </div>

          <div className="text-center">
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Link href="/forum">
                <Button size="lg" className="bg-light-blue hover:bg-accent-blue">
                  <MessageCircle className="mr-2" size={20} />
                  Join the Discussion
                </Button>
              </Link>
              <Link href="/donate">
                <Button variant="outline" size="lg" className="border-2 border-accent-blue text-accent-blue hover:bg-accent-blue hover:text-white">
                  <Heart className="mr-2" size={20} />
                  Support the Project
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
