import { useEffect } from "react";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, Home, Heart } from "lucide-react";

export default function DonateSuccess() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    document.title = "Thank You! - Street Smarts & Bad Decisions";
  }, []);

  return (
    <div className="min-h-screen bg-deep-dark flex items-center justify-center px-4">
      <Card className="w-full max-w-md bg-dark-surface border-green-500/20 border-2">
        <CardContent className="p-8 text-center">
          <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="text-green-400" size={48} />
          </div>
          
          <h1 className="text-3xl font-bold text-text-light mb-4">
            Thank You!
          </h1>
          
          <p className="text-gray-300 mb-2">
            Your donation has been processed successfully.
          </p>
          
          <p className="text-gray-400 text-sm mb-8">
            Your support helps us continue creating meaningful content and building our community.
          </p>

          <div className="flex items-center justify-center mb-8">
            <Heart className="text-red-400 mr-2" size={24} />
            <span className="text-text-light font-semibold">
              We appreciate your support!
            </span>
          </div>

          <div className="space-y-3">
            <Button 
              onClick={() => setLocation("/")}
              className="w-full bg-light-blue hover:bg-accent-blue"
            >
              <Home className="mr-2" size={20} />
              Return to Home
            </Button>
            
            <Button 
              onClick={() => setLocation("/donate")}
              variant="outline"
              className="w-full border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Back to Donations
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}