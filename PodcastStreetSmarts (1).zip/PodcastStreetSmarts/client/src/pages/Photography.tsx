import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Camera } from "lucide-react";
import type { Photo } from "@shared/schema";

export default function Photography() {
  const { data: photos, isLoading } = useQuery<Photo[]>({
    queryKey: ["/api/photos"],
  });

  useEffect(() => {
    document.title = "Photography Portfolio - Street Smarts & Bad Decisions";
  }, []);

  const displayPhotos = photos || [];

  if (isLoading) {
    return (
      <div className="py-20 bg-deep-dark min-h-screen">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <Skeleton className="h-12 w-96 mx-auto mb-4" />
            <Skeleton className="h-6 w-128 mx-auto" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <Skeleton key={i} className="h-80 w-full rounded-xl" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="py-20 bg-deep-dark min-h-screen">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-text-light">Photography Portfolio</h1>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">Capturing the raw essence of urban life and human stories</p>
        </div>

        {/* Photography Grid */}
        {displayPhotos.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {displayPhotos.map((photo) => (
              <div key={photo.id} className="group relative overflow-hidden rounded-xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2">
                <img 
                  src={photo.imageUrl} 
                  alt={photo.title} 
                  className="w-full h-80 object-cover group-hover:scale-110 transition-transform duration-500"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="absolute bottom-4 left-4 right-4">
                    <h4 className="text-white font-semibold mb-1">{photo.title}</h4>
                    <p className="text-gray-300 text-sm">{photo.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : !isLoading && (
          <div className="text-center py-16">
            <div className="w-24 h-24 mx-auto mb-6 bg-gradient-to-r from-light-blue to-accent-blue rounded-full flex items-center justify-center opacity-50">
              <Camera className="text-white" size={32} />
            </div>
            <h3 className="text-2xl font-bold text-text-light mb-4">Gallery Coming Soon</h3>
            <p className="text-gray-400 mb-8">We're curating an amazing collection of urban photography. Check back soon!</p>
          </div>
        )}

        {displayPhotos.length > 0 && (
          <div className="text-center mt-12">
            <Button className="bg-light-blue hover:bg-accent-blue px-8 py-3">
              View Full Gallery
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
