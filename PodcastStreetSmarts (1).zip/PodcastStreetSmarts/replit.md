# Street Smarts & Bad Decisions - Podcast & Photography Platform

## Overview

This is a full-stack web application for a podcast and photography community called "Street Smarts & Bad Decisions." The platform combines content delivery, community engagement, and artistic expression through a modern React frontend and Express backend architecture.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom dark theme color scheme
- **Routing**: wouter for client-side routing
- **State Management**: TanStack React Query for server state management
- **Component Structure**: Modular component architecture with shared UI components

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API endpoints for videos, photos, and forum posts
- **Development Server**: Custom Vite integration for SSR capabilities
- **Request Handling**: Express middleware for JSON parsing, CORS, and request logging

### Database Layer
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Database**: Configured for PostgreSQL via Neon Database serverless
- **Schema Management**: Centralized schema definitions in shared directory
- **Validation**: Zod schemas for runtime type validation

## Key Components

### Content Management
- **Videos**: Podcast episodes with metadata (title, description, thumbnail, duration, category)
- **Photography**: Image gallery with categorization and descriptions
- **Forum**: Community discussion posts with threaded conversations
- **Categories**: Street Smarts, Bad Decisions, Photography, and General content types

### User Interface
- **Responsive Design**: Mobile-first approach with adaptive layouts
- **Dark Theme**: Custom color scheme optimized for urban aesthetic
- **Component Library**: Comprehensive UI component set including cards, buttons, forms, and navigation
- **Interactive Elements**: Hover states, transitions, and loading states

### Navigation Structure
- Home page with hero section and featured content
- Dedicated pages for Videos, Photography, Street Smarts, and Bad Decisions content
- Community Forum for user engagement
- About and Donate pages for platform information and support

## Data Flow

### Request Lifecycle
1. Client requests routed through wouter router
2. React Query manages data fetching and caching
3. API requests processed by Express middleware stack
4. Business logic handled by storage abstraction layer
5. Database operations performed via Drizzle ORM
6. Response data validated with Zod schemas

### Storage Abstraction
- Interface-based storage design allowing multiple implementations
- Current in-memory storage for development
- Database-backed storage ready for production deployment
- Consistent API across different storage backends

## External Dependencies

### Core Technologies
- React ecosystem (React, React DOM, React Query)
- Express.js with TypeScript support
- Drizzle ORM with PostgreSQL driver
- Vite build toolchain with React plugin

### UI and Styling
- Radix UI component primitives
- Tailwind CSS for utility-first styling
- Lucide React for consistent iconography
- React Icons for social media icons

### Development Tools
- TypeScript for type safety
- ESLint and Prettier for code quality
- PostCSS for CSS processing
- Replit integration for development environment

## Deployment Strategy

### Build Process
- Frontend: Vite builds optimized production bundle
- Backend: esbuild compiles TypeScript to ES modules
- Assets: Static files served from dist/public directory
- Environment: NODE_ENV-based configuration switching

### Database Setup
- Drizzle migrations manage schema changes
- Environment variable configuration for database connection
- Push-based deployment for development environments
- Production-ready PostgreSQL integration via Neon Database

### Hosting Configuration
- Express server handles both API routes and static file serving
- Vite development middleware for hot module replacement
- Production build serves static files with API fallback
- Environment-specific logging and error handling

## Changelog

```
Changelog:
- June 30, 2025. Initial setup
- June 30, 2025. Added comprehensive admin dashboard with authentication
  * Integrated Replit OpenID Connect authentication
  * Created admin dashboard with video/photo/forum/settings management
  * Added database integration with PostgreSQL
  * Implemented role-based access control for admin users
  * Created complete CRUD operations for all content types
  * Added site customization features (colors, social links, Stripe integration)
- July 10, 2025. Made admin dashboard fully responsive for mobile and desktop
  * Added mobile-first responsive design with custom breakpoints (xs: 475px)
  * Implemented scrollable horizontal tabs for mobile admin navigation
  * Made all admin cards, buttons, and content sections mobile-responsive
  * Fixed duplicate QuickActions component causing button functionality issues
  * Optimized text sizes and spacing for different screen sizes
  * Cleaned all fake/sample data from admin interface
  * Replaced all instances of "Nichole" with "Malissa" throughout admin components
  * Set all file counts and storage usage to zero for fresh start
- July 11, 2025. Implemented secure admin authentication and PayPal donation integration
  * Created AdminLogin page with username/password authentication (ssbd/4200)
  * Added bcrypt password hashing for secure admin credential storage
  * Implemented PayPal payment processing for donations ($5, $15, $50, custom amounts)
  * Added admin login/logout API endpoints with session management
  * Integrated PayPal sandbox configuration with client ID and secret
  * Created donation success/failure handling with proper error messages
  * Added custom donation amount input for flexible payment options
```

## User Preferences

```
Website owner: Malissa
Preferred communication style: Simple, everyday language.
Admin user needs: Complete control over website content, comments, and appearance with user-friendly interface.
Security preference: Admin access hidden from regular users.
```